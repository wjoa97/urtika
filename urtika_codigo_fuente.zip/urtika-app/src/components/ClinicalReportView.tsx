import React, { useState } from 'react';
import {
  FileText,
  Printer,
  Calendar,
  MapPin,
  Clock,
  Pill,
  ShieldAlert,
  FileDown,
  Camera,
  Image as ImageIcon,
  CheckCircle,
  X,
} from 'lucide-react';
import { AllergyReaction } from '../types/allergy';
import { parseDurationToMinutes } from '../utils/dateAndUas';
import { generateClinicalReportPDF } from '../utils/pdfGenerator';

interface ClinicalReportViewProps {
  reactions: AllergyReaction[];
}

export const ClinicalReportView: React.FC<ClinicalReportViewProps> = ({
  reactions,
}) => {
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);

  const totalPhotos = reactions.reduce((acc, r) => acc + (r.fotos?.length || 0), 0);

  // Group by week
  const weeksMap: { [week: number]: AllergyReaction[] } = {};
  reactions.forEach((r) => {
    if (!weeksMap[r.semana]) {
      weeksMap[r.semana] = [];
    }
    weeksMap[r.semana].push(r);
  });

  const weeksSorted = Object.keys(weeksMap)
    .map(Number)
    .sort((a, b) => b - a);

  // Body areas frequency
  const bodyCounts: { [area: string]: number } = {};
  reactions.forEach((r) => {
    const text = r.ubicacionCuerpo || 'Sin especificar';
    // Match common keywords
    if (/codo/i.test(text)) bodyCounts['Codos'] = (bodyCounts['Codos'] || 0) + 1;
    if (/brazo/i.test(text)) bodyCounts['Brazos'] = (bodyCounts['Brazos'] || 0) + 1;
    if (/pierna/i.test(text)) bodyCounts['Piernas'] = (bodyCounts['Piernas'] || 0) + 1;
    if (/hombro/i.test(text)) bodyCounts['Hombros'] = (bodyCounts['Hombros'] || 0) + 1;
    if (/cuello/i.test(text)) bodyCounts['Cuello'] = (bodyCounts['Cuello'] || 0) + 1;
    if (/espalda/i.test(text)) bodyCounts['Espalda'] = (bodyCounts['Espalda'] || 0) + 1;
  });

  // Location frequency
  const locationCounts: { [loc: string]: number } = {};
  reactions.forEach((r) => {
    const loc = r.ubicacion ? r.ubicacion.trim() : 'Sin ubicación';
    locationCounts[loc] = (locationCounts[loc] || 0) + 1;
  });

  // Calculate average disappearance time
  const timesWithMed: number[] = [];
  const timesWithoutMed: number[] = [];

  reactions.forEach((r) => {
    const mins = parseDurationToMinutes(r.tiempoDesaparecer);
    if (mins > 0) {
      if (r.tomoMedicamento) {
        timesWithMed.push(mins);
      } else {
        timesWithoutMed.push(mins);
      }
    }
  });

  const avgWithMed =
    timesWithMed.length > 0
      ? Math.round(timesWithMed.reduce((a, b) => a + b, 0) / timesWithMed.length)
      : null;

  const avgWithoutMed =
    timesWithoutMed.length > 0
      ? Math.round(
          timesWithoutMed.reduce((a, b) => a + b, 0) / timesWithoutMed.length
        )
      : null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Printable Clinical Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-xl shadow-2xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-[#f5f5f5] flex items-center gap-2">
            <FileText className="w-5 h-5 text-slate-700 dark:text-[#7f91a4]" />
            Informe Clínico y Puntuación UAS7 (Urticaria Activity Score)
          </h2>
          <p className="text-xs text-slate-500 dark:text-[#7f91a4] mt-1 max-w-2xl">
            Resumen médico estructurado para consulta con alergólogo o dermatólogo, basado en la
            escala clínica internacional UAS7.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
          <button
            onClick={() => {
              if (totalPhotos > 0) {
                setIsPdfModalOpen(true);
              } else {
                generateClinicalReportPDF(reactions, { includePhotos: false });
              }
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/50 border border-rose-200 dark:border-rose-800 rounded-lg transition-colors whitespace-nowrap cursor-pointer shadow-2xs"
            title="Descargar informe médico completo estructurado en PDF para el alergólogo"
          >
            <FileDown className="w-4 h-4 text-rose-600 dark:text-rose-400" />
            <span>Descargar Informe PDF</span>
          </button>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-[#f5f5f5] bg-slate-100 dark:bg-[#17212b] hover:bg-slate-200 dark:hover:bg-[#2b394a] border border-slate-300 dark:border-[#1e2c3a] rounded-lg transition-colors whitespace-nowrap"
          >
            <Printer className="w-4 h-4 text-slate-600 dark:text-[#7f91a4]" />
            <span>Imprimir</span>
          </button>
        </div>
      </div>

      {/* UAS7 Weekly Scorecards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {weeksSorted.map((weekNum) => {
          const recs = weeksMap[weekNum];
          const totalUAS7 = recs.reduce((acc, curr) => acc + curr.puntuacionDia, 0);

          let classification = '';
          let badgeColor = '';
          if (totalUAS7 === 0) {
            classification = 'Control total de urticaria';
            badgeColor = 'text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800';
          } else if (totalUAS7 <= 6) {
            classification = 'Urticaria bien controlada';
            badgeColor = 'text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800';
          } else if (totalUAS7 <= 15) {
            classification = 'Urticaria leve';
            badgeColor = 'text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800';
          } else if (totalUAS7 <= 27) {
            classification = 'Urticaria moderada';
            badgeColor = 'text-orange-700 dark:text-orange-300 bg-orange-50 dark:bg-orange-950/40 border-orange-200 dark:border-orange-800';
          } else {
            classification = 'Urticaria severa';
            badgeColor = 'text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800';
          }

          return (
            <div
              key={weekNum}
              className="bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-xl p-4 flex flex-col justify-between shadow-2xs"
            >
              <div>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-slate-500 dark:text-[#7f91a4]" />
                    <h3 className="text-sm font-bold text-slate-900 dark:text-[#f5f5f5]">
                      Semana {weekNum}
                    </h3>
                  </div>
                  <span
                    className={`text-xs px-2.5 py-0.5 rounded-full font-bold border ${badgeColor}`}
                  >
                    UAS7: {totalUAS7} / 42
                  </span>
                </div>

                <div className="text-xs text-slate-600 dark:text-[#7f91a4] mb-3 font-medium">
                  Diagnóstico semanal: <strong className="text-slate-900 dark:text-[#f5f5f5]">{classification}</strong>
                </div>

                <div className="space-y-1 text-xs text-slate-600 dark:text-[#7f91a4] bg-slate-50 dark:bg-[#17212b] p-2.5 rounded-lg border border-slate-100 dark:border-[#1e2c3a]">
                  <div className="flex justify-between">
                    <span>Brotes registrados en la semana:</span>
                    <strong className="font-mono text-slate-900 dark:text-[#f5f5f5]">{recs.length}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Promedio ronchas:</span>
                    <strong className="font-mono text-slate-900 dark:text-[#f5f5f5]">
                      {(
                        recs.reduce((a, b) => a + b.ronchas, 0) / recs.length
                      ).toFixed(1)} / 3
                    </strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Promedio prurito (picor):</span>
                    <strong className="font-mono text-slate-900 dark:text-[#f5f5f5]">
                      {(
                        recs.reduce((a, b) => a + b.prurito, 0) / recs.length
                      ).toFixed(1)} / 3
                    </strong>
                  </div>
                </div>
              </div>

              <div className="mt-3 text-[11px] text-slate-500 dark:text-[#7f91a4]">
                UAS7 es la suma de los valores diarios de ronchas y prurito recomendada por las guías
                médicas EAACI/GA²LEN/EDF/WAO.
              </div>
            </div>
          );
        })}
      </div>

      {/* Clinical Patterns & Triggers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Most affected zones */}
        <div className="bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-xl p-4 shadow-2xs">
          <h4 className="text-xs font-bold text-slate-900 dark:text-[#f5f5f5] uppercase tracking-wide mb-3 flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 text-slate-600 dark:text-[#7f91a4]" />
            Zonas más frecuentes
          </h4>
          <div className="space-y-2">
            {Object.keys(bodyCounts).length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-[#7f91a4]">Sin datos de zonas aún.</p>
            ) : (
              Object.entries(bodyCounts)
                .sort((a, b) => b[1] - a[1])
                .map(([area, count]) => (
                  <div key={area} className="flex items-center justify-between text-xs">
                    <span className="text-slate-700 dark:text-[#f5f5f5]">{area}</span>
                    <span className="font-mono tabular-nums font-bold text-slate-900 dark:text-[#f5f5f5] bg-slate-100 dark:bg-[#17212b] px-2 py-0.5 rounded">
                      {count} {count === 1 ? 'vez' : 'veces'}
                    </span>
                  </div>
                ))
            )}
          </div>
        </div>

        {/* Environments */}
        <div className="bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-xl p-4 shadow-2xs">
          <h4 className="text-xs font-bold text-slate-900 dark:text-[#f5f5f5] uppercase tracking-wide mb-3 flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-slate-600 dark:text-[#7f91a4]" />
            Entornos del brote
          </h4>
          <div className="space-y-2">
            {Object.entries(locationCounts)
              .sort((a, b) => b[1] - a[1])
              .map(([loc, count]) => (
                <div key={loc} className="flex items-center justify-between text-xs">
                  <span className="text-slate-700 dark:text-[#f5f5f5]">{loc}</span>
                  <span className="font-mono tabular-nums font-bold text-slate-900 dark:text-[#f5f5f5] bg-slate-100 dark:bg-[#17212b] px-2 py-0.5 rounded">
                    {count} {count === 1 ? 'registro' : 'registros'}
                  </span>
                </div>
              ))}
          </div>
        </div>

        {/* Resolution Time & Medication Efficacy */}
        <div className="bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-xl p-4 shadow-2xs">
          <h4 className="text-xs font-bold text-slate-900 dark:text-[#f5f5f5] uppercase tracking-wide mb-3 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-slate-600 dark:text-[#7f91a4]" />
            Tiempo de resolución
          </h4>
          <div className="space-y-3 text-xs">
            <div className="bg-slate-50 dark:bg-[#17212b] p-2.5 rounded-lg border border-slate-100 dark:border-[#1e2c3a]">
              <div className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-[#7f91a4] mb-0.5">
                <Pill className="w-3 h-3 text-slate-400 dark:text-[#7f91a4]" />
                Con medicación:
              </div>
              <div className="font-mono text-sm font-bold text-slate-900 dark:text-[#f5f5f5]">
                {avgWithMed !== null ? `~${avgWithMed} minutos` : 'Sin registros suficientes'}
              </div>
            </div>

            <div className="bg-slate-50 dark:bg-[#17212b] p-2.5 rounded-lg border border-slate-100 dark:border-[#1e2c3a]">
              <div className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-[#7f91a4] mb-0.5">
                <Clock className="w-3 h-3 text-slate-400 dark:text-[#7f91a4]" />
                Sin medicación (espontáneo):
              </div>
              <div className="font-mono text-sm font-bold text-slate-900 dark:text-[#f5f5f5]">
                {avgWithoutMed !== null ? `~${avgWithoutMed} minutos` : 'Sin registros suficientes'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal: Ask whether to include photos in the clinical PDF report */}
      {isPdfModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 dark:bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
          <div
            className="bg-white dark:bg-[#242f3d] w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 dark:border-[#1e2c3a] overflow-hidden animate-in zoom-in-95 duration-200"
            role="dialog"
            aria-modal="true"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-[#1e2c3a] bg-slate-50/80 dark:bg-[#17212b]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900/60 flex items-center justify-center text-rose-600 dark:text-rose-400">
                  <FileDown className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-[#f5f5f5] text-sm">
                    Generar Informe PDF
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-[#7f91a4]">
                    Opciones de exportación clínica
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsPdfModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 dark:text-[#7f91a4] hover:text-slate-700 dark:hover:text-[#f5f5f5] hover:bg-slate-100 dark:hover:bg-[#2b394a] transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4">
              <div className="text-center sm:text-left">
                <p className="text-sm font-semibold text-slate-800 dark:text-[#f5f5f5]">
                  ¿Deseas incluir las fotografías de los brotes en el informe PDF?
                </p>
                <p className="text-xs text-slate-500 dark:text-[#7f91a4] mt-1">
                  Tienes <span className="font-bold text-rose-600 dark:text-rose-400">{totalPhotos}</span> {totalPhotos === 1 ? 'fotografía adjunta' : 'fotografías adjuntas'} en tus registros de alergia.
                </p>
              </div>

              {/* Choices Cards */}
              <div className="space-y-2.5">
                {/* Option 1: Con imágenes */}
                <button
                  type="button"
                  onClick={() => {
                    generateClinicalReportPDF(reactions, { includePhotos: true });
                    setIsPdfModalOpen(false);
                  }}
                  className="w-full text-left p-3.5 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/50 dark:bg-rose-950/30 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-all group cursor-pointer shadow-2xs"
                >
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-rose-100 dark:bg-rose-900/60 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5">
                      <Camera className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-slate-900 dark:text-[#f5f5f5]">
                          Sí, incluir fotos en el PDF
                        </span>
                        <span className="text-[10px] font-bold text-rose-700 dark:text-rose-300 bg-rose-100 dark:bg-rose-900/60 px-1.5 py-0.2 rounded-full">
                          Recomendado
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-[#7f91a4] mt-0.5">
                        Añade un anexo fotográfico de alta calidad con cada lesión cutánea, fecha, zona corporal y puntuación UAS para el alergólogo.
                      </p>
                    </div>
                  </div>
                </button>

                {/* Option 2: Sin imágenes */}
                <button
                  type="button"
                  onClick={() => {
                    generateClinicalReportPDF(reactions, { includePhotos: false });
                    setIsPdfModalOpen(false);
                  }}
                  className="w-full text-left p-3.5 rounded-xl border border-slate-200 dark:border-[#1e2c3a] bg-slate-50/60 dark:bg-[#17212b] hover:bg-slate-100 dark:hover:bg-[#1e2c3a] transition-all group cursor-pointer shadow-2xs"
                >
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-slate-200 dark:bg-[#242f3d] text-slate-700 dark:text-[#7f91a4] shrink-0 mt-0.5">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <span className="font-bold text-xs text-slate-900 dark:text-[#f5f5f5] block">
                        No, solo datos clínicos tabulares
                      </span>
                      <p className="text-[11px] text-slate-500 dark:text-[#7f91a4] mt-0.5">
                        Genera el informe resumido clásico con tablas de evolución y escalas semanales UAS7 (archivo más ligero).
                      </p>
                    </div>
                  </div>
                </button>
              </div>

              {/* Cancel Button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setIsPdfModalOpen(false)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 dark:text-[#7f91a4] hover:text-slate-900 dark:hover:text-[#f5f5f5] transition-colors"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
