import React, { useState, useEffect, useRef } from 'react';
import {
  Copy,
  Download,
  Filter,
  Search,
  Trash2,
  Edit2,
  CopyPlus,
  Check,
  Plus,
  FileDown,
  Upload,
  Eye,
  Calendar,
  X,
  ChevronDown,
  Camera,
} from 'lucide-react';
import { AllergyReaction } from '../types/allergy';
import { exportToTSV, exportToCSV } from '../utils/dateAndUas';
import { generateSpreadsheetPDF } from '../utils/pdfGenerator';
import { parseCSVToReactions } from '../utils/csvImporter';
import { ReactionDetailModal } from './ReactionDetailModal';
import { PhotoLightboxModal } from './PhotoLightboxModal';

interface SpreadsheetViewProps {
  reactions: AllergyReaction[];
  onEdit: (reaction: AllergyReaction) => void;
  onDelete: (id: string) => void;
  onDuplicate: (reaction: AllergyReaction) => void;
  onAddNew: () => void;
  onImportReactions?: (newReactions: AllergyReaction[]) => void;
}

export const SpreadsheetView: React.FC<SpreadsheetViewProps> = ({
  reactions,
  onEdit,
  onDelete,
  onDuplicate,
  onAddNew,
  onImportReactions,
}) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedWeek, setSelectedWeek] = useState<string>('all');
  const [selectedTimePeriod, setSelectedTimePeriod] = useState<string>('all');
  const [customStartDate, setCustomStartDate] = useState<string>('');
  const [customEndDate, setCustomEndDate] = useState<string>('');
  const [importMessage, setImportMessage] = useState<string | null>(null);

  // State for the "Ampliar / Ver detalle" modal
  const [selectedReactionForDetail, setSelectedReactionForDetail] =
    useState<AllergyReaction | null>(null);
  const [previewPhotoUrl, setPreviewPhotoUrl] = useState<string | null>(null);
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState<boolean>(false);
  const [isExportMenuOpen, setIsExportMenuOpen] = useState<boolean>(false);

  // Dual horizontal scrollbar synchronization refs and state
  const topScrollRef = useRef<HTMLDivElement>(null);
  const tableContainerRef = useRef<HTMLDivElement>(null);
  const tableRef = useRef<HTMLTableElement>(null);
  const isSyncingRef = useRef<boolean>(false);
  const [tableScrollWidth, setTableScrollWidth] = useState<number>(0);
  const topRafRef = useRef<number | null>(null);
  const bottomRafRef = useRef<number | null>(null);

  useEffect(() => {
    const updateWidth = () => {
      if (tableRef.current) {
        setTableScrollWidth(tableRef.current.scrollWidth);
      }
    };

    updateWidth();

    let observer: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined' && tableRef.current) {
      observer = new ResizeObserver(() => {
        updateWidth();
      });
      observer.observe(tableRef.current);
    }

    window.addEventListener('resize', updateWidth);
    return () => {
      if (observer) observer.disconnect();
      window.removeEventListener('resize', updateWidth);
      if (topRafRef.current) cancelAnimationFrame(topRafRef.current);
      if (bottomRafRef.current) cancelAnimationFrame(bottomRafRef.current);
    };
  }, [reactions.length]);

  const handleTopScroll = () => {
    if (isSyncingRef.current) return;
    if (topRafRef.current) cancelAnimationFrame(topRafRef.current);

    topRafRef.current = requestAnimationFrame(() => {
      if (topScrollRef.current && tableContainerRef.current) {
        const topPos = topScrollRef.current.scrollLeft;
        if (Math.abs(tableContainerRef.current.scrollLeft - topPos) > 1) {
          isSyncingRef.current = true;
          tableContainerRef.current.scrollLeft = topPos;
          requestAnimationFrame(() => {
            isSyncingRef.current = false;
          });
        }
      }
    });
  };

  const handleBottomScroll = () => {
    if (isSyncingRef.current) return;
    if (bottomRafRef.current) cancelAnimationFrame(bottomRafRef.current);

    // Decouple top-bar sync using requestAnimationFrame to keep mobile momentum scrolling at 60/120fps
    bottomRafRef.current = requestAnimationFrame(() => {
      if (topScrollRef.current && tableContainerRef.current) {
        const bottomPos = tableContainerRef.current.scrollLeft;
        if (Math.abs(topScrollRef.current.scrollLeft - bottomPos) > 1) {
          isSyncingRef.current = true;
          topScrollRef.current.scrollLeft = bottomPos;
          requestAnimationFrame(() => {
            isSyncingRef.current = false;
          });
        }
      }
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const imported = parseCSVToReactions(text);
        if (imported.length > 0) {
          if (onImportReactions) {
            onImportReactions(imported);
          }
          setImportMessage(`¡Éxito! Se importaron ${imported.length} reacciones.`);
          setTimeout(() => setImportMessage(null), 4000);
        } else {
          alert('No se pudieron encontrar filas válidas en el archivo CSV.');
        }
      } catch (err) {
        console.error(err);
        alert('Error al leer el archivo CSV. Comprueba su formato.');
      }
      e.target.value = '';
    };
    reader.readAsText(file);
  };

  // Unique weeks
  const availableWeeks = Array.from(new Set(reactions.map((r) => r.semana))).sort(
    (a, b) => b - a
  );

  // Filtered reactions with full Date / Month / Year / Period / Range logic
  const filtered = reactions.filter((r) => {
    // 1. Week Filter
    if (selectedWeek !== 'all' && String(r.semana) !== selectedWeek) {
      return false;
    }

    // 2. Predefined Time Period Filter
    const reactionDate = new Date(r.fecha);
    const now = new Date();

    if (selectedTimePeriod === 'today') {
      const isToday =
        reactionDate.getFullYear() === now.getFullYear() &&
        reactionDate.getMonth() === now.getMonth() &&
        reactionDate.getDate() === now.getDate();
      if (!isToday) return false;
    } else if (selectedTimePeriod === 'this_month') {
      const isThisMonth =
        reactionDate.getFullYear() === now.getFullYear() &&
        reactionDate.getMonth() === now.getMonth();
      if (!isThisMonth) return false;
    } else if (selectedTimePeriod === 'last_month') {
      const prevMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const isLastMonth =
        reactionDate.getFullYear() === prevMonth.getFullYear() &&
        reactionDate.getMonth() === prevMonth.getMonth();
      if (!isLastMonth) return false;
    } else if (selectedTimePeriod === 'this_year') {
      if (reactionDate.getFullYear() !== now.getFullYear()) return false;
    } else if (selectedTimePeriod === 'last_7_days') {
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(now.getDate() - 7);
      if (reactionDate < sevenDaysAgo || reactionDate > now) return false;
    } else if (selectedTimePeriod === 'last_30_days') {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(now.getDate() - 30);
      if (reactionDate < thirtyDaysAgo || reactionDate > now) return false;
    }

    // 3. Custom Date Range Filter (Desde / Hasta)
    if (customStartDate) {
      const start = new Date(customStartDate);
      start.setHours(0, 0, 0, 0);
      if (reactionDate < start) return false;
    }

    if (customEndDate) {
      const end = new Date(customEndDate);
      end.setHours(23, 59, 59, 999);
      if (reactionDate > end) return false;
    }

    // 4. Search Query Term
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    return (
      r.fechaFormateada.toLowerCase().includes(term) ||
      (r.ubicacion && r.ubicacion.toLowerCase().includes(term)) ||
      (r.ubicacionCuerpo && r.ubicacionCuerpo.toLowerCase().includes(term)) ||
      (r.medicamento && r.medicamento.toLowerCase().includes(term)) ||
      (r.notas && r.notas.toLowerCase().includes(term))
    );
  });

  const clearAllFilters = () => {
    setSelectedWeek('all');
    setSelectedTimePeriod('all');
    setCustomStartDate('');
    setCustomEndDate('');
    setSearchTerm('');
  };

  const hasActiveFilters =
    selectedWeek !== 'all' ||
    selectedTimePeriod !== 'all' ||
    Boolean(customStartDate) ||
    Boolean(customEndDate) ||
    Boolean(searchTerm.trim());

  const handleCopyForSheets = async () => {
    const tsvData = exportToTSV(filtered);
    try {
      await navigator.clipboard.writeText(tsvData);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  const handleDownloadCSV = () => {
    const csvData = exportToCSV(filtered);
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `registro_reacciones_alergicas_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 max-w-full overflow-hidden">
      {/* Table Toolbar & Advanced Filters */}
      <div className="flex flex-col gap-2.5 p-3 bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-xl shadow-2xs">
        {/* Row 1: Search Box + Dedicated "Filtrar" Button */}
        <div className="flex items-center gap-2 w-full">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 dark:text-[#7f91a4] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por zona, notas, medicamento..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-[#17212b] border border-slate-200 dark:border-[#1e2c3a] text-slate-800 dark:text-[#f5f5f5] placeholder:text-slate-400 dark:placeholder:text-[#7f91a4] rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-400 dark:focus:ring-[#5288c1] font-medium"
            />
          </div>

          {/* Dedicated "Filtrar" Button with Active Filter Count Badge */}
          <button
            type="button"
            onClick={() => setIsFilterPanelOpen(!isFilterPanelOpen)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all shrink-0 select-none shadow-2xs ${
              isFilterPanelOpen || hasActiveFilters
                ? 'bg-slate-900 dark:bg-[#5288c1] text-white border-slate-900 dark:border-[#5288c1] shadow-xs'
                : 'bg-white dark:bg-[#242f3d] text-slate-700 dark:text-[#f5f5f5] border-slate-300 dark:border-[#1e2c3a] hover:bg-slate-50 dark:hover:bg-[#2b394a]'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Filtrar</span>
            {hasActiveFilters && (
              <span className="w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] font-bold flex items-center justify-center ml-0.5">
                !
              </span>
            )}
          </button>
        </div>

        {/* Collapsible Filter Panel: Opens smoothly upon clicking "Filtrar" */}
        {isFilterPanelOpen && (
          <div className="p-3 bg-slate-50/90 dark:bg-[#17212b]/95 border border-slate-200 dark:border-[#1e2c3a] rounded-xl space-y-2.5 animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-700 dark:text-[#7f91a4] uppercase tracking-wider">
                Filtros por Fecha y Semana
              </span>
              {hasActiveFilters && (
                <button
                  type="button"
                  onClick={clearAllFilters}
                  className="text-[11px] font-semibold text-rose-600 dark:text-rose-400 hover:text-rose-800 dark:hover:text-rose-300 flex items-center gap-1"
                >
                  <X className="w-3 h-3" />
                  <span>Limpiar todos los filtros</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Period Dropdown */}
              <div>
                <label className="block text-[10px] font-semibold text-slate-500 dark:text-[#7f91a4] uppercase mb-1">
                  Período Temporal:
                </label>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400 dark:text-[#7f91a4] shrink-0" />
                  <select
                    value={selectedTimePeriod}
                    onChange={(e) => {
                      setSelectedTimePeriod(e.target.value);
                      if (e.target.value !== 'custom') {
                        setCustomStartDate('');
                        setCustomEndDate('');
                      }
                    }}
                    className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-lg text-slate-800 dark:text-[#f5f5f5] font-medium focus:outline-none"
                  >
                    <option value="all">Todo el tiempo</option>
                    <option value="today">Hoy</option>
                    <option value="last_7_days">Últimos 7 días</option>
                    <option value="this_month">Este mes</option>
                    <option value="last_month">Mes anterior</option>
                    <option value="this_year">Este año</option>
                    <option value="custom">📅 Elegir rango de fechas (Desde / Hasta)...</option>
                  </select>
                </div>
              </div>

              {/* Week Dropdown */}
              <div>
                <label className="block text-[10px] font-semibold text-slate-500 dark:text-[#7f91a4] uppercase mb-1">
                  Filtrar por Semana:
                </label>
                <select
                  value={selectedWeek}
                  onChange={(e) => setSelectedWeek(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-lg text-slate-800 dark:text-[#f5f5f5] font-medium focus:outline-none"
                >
                  <option value="all">Todas las semanas ({reactions.length})</option>
                  {availableWeeks.map((w) => (
                    <option key={w} value={String(w)}>
                      Semana {w}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Custom Range: Dates Pickers */}
            {selectedTimePeriod === 'custom' && (
              <div className="pt-2 border-t border-slate-200/80 dark:border-[#1e2c3a] flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-medium text-slate-600 dark:text-[#7f91a4]">Desde:</span>
                  <input
                    type="date"
                    value={customStartDate}
                    onChange={(e) => setCustomStartDate(e.target.value)}
                    className="px-2 py-1 text-xs bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-md text-slate-800 dark:text-[#f5f5f5] focus:outline-none"
                  />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-medium text-slate-600 dark:text-[#7f91a4]">Hasta:</span>
                  <input
                    type="date"
                    value={customEndDate}
                    onChange={(e) => setCustomEndDate(e.target.value)}
                    className="px-2 py-1 text-xs bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-md text-slate-800 dark:text-[#f5f5f5] focus:outline-none"
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Row 3: Action Buttons (Grouped Export Menu + New Row) */}
        <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-100 dark:border-[#1e2c3a] relative">
          <div className="flex items-center gap-2">
            {/* Unified Export / Download Dropdown Menu */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsExportMenuOpen(!isExportMenuOpen)}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all shadow-2xs whitespace-nowrap ${
                  isExportMenuOpen
                    ? 'bg-slate-900 dark:bg-[#5288c1] text-white border-slate-900 dark:border-[#5288c1]'
                    : 'bg-white dark:bg-[#242f3d] text-slate-700 dark:text-[#f5f5f5] border-slate-300 dark:border-[#1e2c3a] hover:bg-slate-50 dark:hover:bg-[#2b394a]'
                }`}
                title="Opciones de descarga, exportación y copia de datos"
              >
                <Download className="w-3.5 h-3.5 text-slate-500 dark:text-[#7f91a4]" />
                <span>Descargas / Exportar</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isExportMenuOpen ? 'rotate-180' : ''}`} />
              </button>

              {/* Dropdown Popover */}
              {isExportMenuOpen && (
                <div
                  className="absolute left-0 mt-1.5 w-60 bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-xl shadow-lg z-30 p-1.5 space-y-1 animate-in fade-in zoom-in-95"
                  onMouseLeave={() => setIsExportMenuOpen(false)}
                >
                  <button
                    type="button"
                    onClick={() => {
                      handleCopyForSheets();
                      setIsExportMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 dark:text-[#f5f5f5] hover:bg-slate-100 dark:hover:bg-[#2b394a] rounded-lg transition-colors text-left"
                  >
                    {copied ? (
                      <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    ) : (
                      <Copy className="w-4 h-4 text-slate-500 dark:text-[#7f91a4] shrink-0" />
                    )}
                    <div>
                      <span className="font-semibold block text-slate-900 dark:text-[#f5f5f5]">
                        {copied ? '¡Copiado!' : 'Copiar para Google Sheets'}
                      </span>
                      <span className="text-[10px] text-slate-500 dark:text-[#7f91a4]">
                        Formato tabulado para pegar con Ctrl+V
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      handleDownloadCSV();
                      setIsExportMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 dark:text-[#f5f5f5] hover:bg-slate-100 dark:hover:bg-[#2b394a] rounded-lg transition-colors text-left"
                  >
                    <Download className="w-4 h-4 text-slate-500 dark:text-[#7f91a4] shrink-0" />
                    <div>
                      <span className="font-semibold block text-slate-900 dark:text-[#f5f5f5]">
                        Descargar archivo .CSV
                      </span>
                      <span className="text-[10px] text-slate-500 dark:text-[#7f91a4]">
                        Compatible con Excel y Google Drive
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      generateSpreadsheetPDF(filtered);
                      setIsExportMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-rose-700 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors text-left"
                  >
                    <FileDown className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
                    <div>
                      <span className="font-semibold block text-rose-900 dark:text-rose-200">
                        Descargar informe PDF
                      </span>
                      <span className="text-[10px] text-rose-600/80 dark:text-rose-300/80">
                        Listo para imprimir o enviar al médico
                      </span>
                    </div>
                  </button>

                  <div className="border-t border-slate-100 dark:border-[#1e2c3a] my-1"></div>

                  <label
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-sky-700 dark:text-sky-300 hover:bg-sky-50 dark:hover:bg-sky-950/40 rounded-lg transition-colors cursor-pointer text-left"
                  >
                    <Upload className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
                    <div>
                      <span className="font-semibold block text-sky-900 dark:text-sky-200">
                        Importar CSV
                      </span>
                      <span className="text-[10px] text-sky-600/80 dark:text-sky-300/80">
                        Carga registros previos en archivo CSV
                      </span>
                    </div>
                    <input
                      type="file"
                      accept=".csv,text/csv"
                      onChange={(e) => {
                        handleFileUpload(e);
                        setIsExportMenuOpen(false);
                      }}
                      className="hidden"
                    />
                  </label>
                </div>
              )}
            </div>

            {hasActiveFilters && (
              <button
                type="button"
                onClick={clearAllFilters}
                className="text-xs text-slate-500 dark:text-[#7f91a4] hover:text-slate-800 dark:hover:text-[#f5f5f5] underline font-medium truncate max-w-[180px] sm:max-w-none"
              >
                Limpiar ({filtered.length} de {reactions.length})
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Success Notification on CSV Import */}
      {importMessage && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-emerald-900 dark:text-emerald-200 text-xs font-semibold flex items-center gap-2 animate-fade-in">
          <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <span>{importMessage}</span>
        </div>
      )}

      {/* Spreadsheet Container with Top and Bottom Horizontal Scrollbars */}
      <div className="bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-xl overflow-hidden shadow-2xs">
        {/* Top Horizontal Scrollbar */}
        <div
          ref={topScrollRef}
          onScroll={handleTopScroll}
          className="overflow-x-auto custom-scrollbar smooth-horizontal-scroll border-b border-slate-200 dark:border-[#1e2c3a] bg-slate-50/90 dark:bg-[#17212b] select-none"
          style={{ height: '14px', WebkitOverflowScrolling: 'touch' }}
          title="Barra de desplazamiento horizontal superior"
          aria-label="Barra de desplazamiento horizontal superior"
        >
          <div style={{ width: `${Math.max(tableScrollWidth, 1450)}px`, height: '1px' }} />
        </div>

        {/* Main Table Container with Standard Scrollbar and Sticky Headers */}
        <div
          ref={tableContainerRef}
          onScroll={handleBottomScroll}
          className="overflow-auto custom-scrollbar smooth-horizontal-scroll max-h-[72vh]"
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          <table ref={tableRef} className="w-full text-left border-collapse text-xs">
            <thead className="sticky top-0 z-10 bg-slate-100 dark:bg-[#1e2c3a] shadow-2xs">
              <tr className="border-b border-slate-300 dark:border-[#2b394a] font-bold text-slate-800 dark:text-[#f5f5f5] tracking-tight text-[11px] sm:text-xs">
                <th className="py-3 px-3.5 border-r border-slate-200 dark:border-[#2b394a] whitespace-nowrap min-w-[145px]">
                  Fecha y Hora
                </th>
                <th className="py-3 px-3 border-r border-slate-200 dark:border-[#2b394a] text-center whitespace-nowrap min-w-[65px]">
                  Semana
                </th>
                <th className="py-3 px-3 border-r border-slate-200 dark:border-[#2b394a] whitespace-nowrap min-w-[110px]">
                  Ubicacion
                </th>
                <th className="py-3 px-3.5 border-r border-slate-200 dark:border-[#2b394a] whitespace-nowrap min-w-[190px]">
                  UbicaciónCuerpo
                </th>
                <th className="py-3 px-3 border-r border-slate-200 dark:border-[#2b394a] text-center whitespace-nowrap min-w-[125px]">
                  NºRonchas (0-3)
                </th>
                <th className="py-3 px-3 border-r border-slate-200 dark:border-[#2b394a] text-center whitespace-nowrap min-w-[110px]">
                  Prurito (0-3)
                </th>
                <th className="py-3 px-3 border-r border-slate-200 dark:border-[#2b394a] text-center whitespace-nowrap min-w-[110px]">
                  Puntuación Día
                </th>
                <th className="py-3 px-3 border-r border-slate-200 dark:border-[#2b394a] text-center whitespace-nowrap min-w-[140px]">
                  ¿Tomó medicamento?
                </th>
                <th className="py-3 px-3 border-r border-slate-200 dark:border-[#2b394a] whitespace-nowrap min-w-[130px]">
                  Medicamento
                </th>
                <th className="py-3 px-3 border-r border-slate-200 dark:border-[#2b394a] whitespace-nowrap min-w-[90px]">
                  Dosis
                </th>
                <th className="py-3 px-3 border-r border-slate-200 dark:border-[#2b394a] text-center whitespace-nowrap min-w-[125px]">
                  Tiempo Desaparición
                </th>
                <th className="py-3 px-3 border-r border-slate-200 dark:border-[#2b394a] whitespace-nowrap min-w-[200px]">
                  Notas
                </th>
                <th className="py-3 px-3 text-center whitespace-nowrap min-w-[100px]">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-[#1e2c3a] font-normal">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={13} className="py-12 text-center text-slate-500 dark:text-[#7f91a4]">
                    <p className="font-medium text-slate-600 dark:text-[#f5f5f5]">
                      No se encontraron registros con los filtros seleccionados
                    </p>
                    <p className="text-xs text-slate-400 dark:text-[#7f91a4] mt-1">
                      Prueba a cambiar el rango de fechas o añade una nueva reacción.
                    </p>
                  </td>
                </tr>
              ) : (
                filtered.map((r) => {
                  return (
                    <tr
                      key={r.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-[#2b394a]/40 transition-colors group cursor-pointer"
                      onClick={(e) => {
                        // Prevent triggering detail modal when clicking row action buttons
                        const target = e.target as HTMLElement;
                        if (target.closest('button')) return;
                        setSelectedReactionForDetail(r);
                      }}
                    >
                      {/* Fecha y Hora + Indicador sutil de foto adjunta a la derecha */}
                      <td className="py-3 px-3.5 border-r border-slate-200 dark:border-[#1e2c3a] whitespace-nowrap">
                        <div className="flex items-center justify-between gap-2.5 min-w-[145px]">
                          <span className="font-mono text-slate-900 dark:text-[#f5f5f5] font-medium">{r.fechaFormateada}</span>
                          {r.fotos && r.fotos.length > 0 && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                if (r.fotos && r.fotos.length > 0) {
                                  setPreviewPhotoUrl(r.fotos[0]);
                                }
                              }}
                              className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-[#17212b] hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-600 dark:text-[#7f91a4] hover:text-rose-700 dark:hover:text-rose-300 border border-slate-200 dark:border-[#2b394a] hover:border-rose-300 text-[10px] font-semibold transition-colors shrink-0 shadow-2xs"
                              title={`Tiene ${r.fotos.length} foto(s) de la erupción. Clic para ver y hacer zoom`}
                            >
                              <Camera className="w-3 h-3 text-rose-600 dark:text-rose-400" />
                              <span>{r.fotos.length}</span>
                            </button>
                          )}
                        </div>
                      </td>

                      {/* Semana */}
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-[#1e2c3a] text-center font-mono font-semibold text-slate-700 dark:text-[#7f91a4] whitespace-nowrap">
                        {r.semana}
                      </td>

                      {/* Ubicación */}
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-[#1e2c3a] text-slate-800 dark:text-[#f5f5f5] whitespace-nowrap">
                        {r.ubicacion || (
                          <span className="text-slate-300 dark:text-slate-600">-</span>
                        )}
                      </td>

                      {/* Ubicación en el cuerpo */}
                      <td className="py-3 px-3.5 border-r border-slate-200 dark:border-[#1e2c3a] text-slate-800 dark:text-[#f5f5f5] whitespace-nowrap max-w-[220px] truncate" title={r.ubicacionCuerpo}>
                        {r.ubicacionCuerpo || (
                          <span className="text-slate-300 dark:text-slate-600">-</span>
                        )}
                      </td>

                      {/* Nº Ronchas (0-3) with clear clinical label */}
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-[#1e2c3a] text-center whitespace-nowrap">
                        {(() => {
                          const val = r.ronchas ?? (r as any).numHabones ?? 0;
                          const config = [
                            { text: '0 · Ninguna', bg: 'bg-slate-100 dark:bg-[#17212b] text-slate-600 dark:text-[#7f91a4] border-slate-200 dark:border-[#2b394a]' },
                            { text: '1 · Leve (<20)', bg: 'bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800' },
                            { text: '2 · Moderado (20-50)', bg: 'bg-orange-50 dark:bg-orange-950/40 text-orange-800 dark:text-orange-300 border-orange-200 dark:border-orange-800' },
                            { text: '3 · Severo (>50)', bg: 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800' },
                          ][val] || { text: `${val}`, bg: 'bg-slate-100 dark:bg-[#17212b] text-slate-700 dark:text-[#7f91a4] border-slate-200 dark:border-[#2b394a]' };

                          return (
                            <span className={`inline-block px-2 py-0.5 rounded font-mono text-[11px] font-semibold border ${config.bg}`}>
                              {config.text}
                            </span>
                          );
                        })()}
                      </td>

                      {/* Prurito (0-3) with clear clinical label */}
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-[#1e2c3a] text-center whitespace-nowrap">
                        {(() => {
                          const val = r.prurito ?? 0;
                          const config = [
                            { text: '0 · Sin picor', bg: 'bg-slate-100 dark:bg-[#17212b] text-slate-600 dark:text-[#7f91a4] border-slate-200 dark:border-[#2b394a]' },
                            { text: '1 · Leve', bg: 'bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800' },
                            { text: '2 · Moderado', bg: 'bg-orange-50 dark:bg-orange-950/40 text-orange-800 dark:text-orange-300 border-orange-200 dark:border-orange-800' },
                            { text: '3 · Intenso', bg: 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800' },
                          ][val] || { text: `${val}`, bg: 'bg-slate-100 dark:bg-[#17212b] text-slate-700 dark:text-[#7f91a4] border-slate-200 dark:border-[#2b394a]' };

                          return (
                            <span className={`inline-block px-2 py-0.5 rounded font-mono text-[11px] font-semibold border ${config.bg}`}>
                              {config.text}
                            </span>
                          );
                        })()}
                      </td>

                      {/* Puntuación Día (0-6) */}
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-[#1e2c3a] text-center whitespace-nowrap">
                        <span
                          className={`inline-block font-mono font-bold px-2.5 py-0.5 rounded-full text-[11px] ${
                            r.puntuacionDia === 0
                              ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                              : r.puntuacionDia <= 2
                              ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300'
                              : r.puntuacionDia <= 4
                              ? 'bg-orange-100 dark:bg-orange-950/60 text-orange-800 dark:text-orange-300'
                              : 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300'
                          }`}
                        >
                          {r.puntuacionDia} / 6
                        </span>
                      </td>

                      {/* ¿Tomó medicamento? */}
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-[#1e2c3a] text-center whitespace-nowrap">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                            r.tomoMedicamento
                              ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                              : 'text-slate-400 dark:text-slate-500'
                          }`}
                        >
                          {r.tomoMedicamento ? 'SÍ' : 'NO'}
                        </span>
                      </td>

                      {/* Medicamento */}
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-[#1e2c3a] text-slate-800 dark:text-[#f5f5f5] whitespace-nowrap">
                        {r.medicamento || (
                          <span className="text-slate-300 dark:text-slate-600">-</span>
                        )}
                      </td>

                      {/* Dosis */}
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-[#1e2c3a] text-slate-800 dark:text-[#f5f5f5] whitespace-nowrap">
                        {r.dosis ? (
                          <span className="font-mono">{r.dosis}</span>
                        ) : (
                          <span className="text-slate-300 dark:text-slate-600">-</span>
                        )}
                      </td>

                      {/* Tiempo en desaparecer */}
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-[#1e2c3a] text-center font-mono tabular-nums text-slate-800 dark:text-[#f5f5f5] whitespace-nowrap">
                        {r.tiempoDesaparecer || (
                          <span className="text-slate-300 dark:text-slate-600">-</span>
                        )}
                      </td>

                      {/* Notas */}
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-[#1e2c3a] text-slate-700 dark:text-[#7f91a4] max-w-[220px] truncate" title={r.notas}>
                        {r.notas || <span className="text-slate-300 dark:text-slate-600">-</span>}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => onEdit(r)}
                            className="p-1 text-slate-500 dark:text-[#7f91a4] hover:text-slate-900 dark:hover:text-[#f5f5f5] hover:bg-slate-200 dark:hover:bg-[#2b394a] rounded transition-colors"
                            title="Editar fila"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDuplicate(r)}
                            className="p-1 text-slate-500 dark:text-[#7f91a4] hover:text-slate-900 dark:hover:text-[#f5f5f5] hover:bg-slate-200 dark:hover:bg-[#2b394a] rounded transition-colors"
                            title="Duplicar como nueva reacción"
                          >
                            <CopyPlus className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDelete(r.id)}
                            className="p-1 text-slate-400 dark:text-[#7f91a4] hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded transition-colors"
                            title="Eliminar fila"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer with Summary Stats */}
        <div className="flex flex-wrap items-center justify-between px-4 py-2.5 bg-slate-50 dark:bg-[#1e2c3a] border-t border-slate-200 dark:border-[#1e2c3a] text-xs text-slate-600 dark:text-[#7f91a4]">
          <div className="flex items-center gap-4">
            <span>
              Total filas:{' '}
              <strong className="font-mono tabular-nums text-slate-900 dark:text-[#f5f5f5]">
                {filtered.length}
              </strong>
            </span>
            <span aria-hidden="true">·</span>
            <span>
              Puntuación promedio:{' '}
              <strong className="font-mono tabular-nums text-slate-900 dark:text-[#f5f5f5]">
                {filtered.length > 0
                  ? (
                      filtered.reduce((acc, curr) => acc + curr.puntuacionDia, 0) /
                      filtered.length
                    ).toFixed(1)
                  : '0.0'}
              </strong>
            </span>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-[#7f91a4]">
            Haz clic en cualquier fila para ampliarla y ver sus fotos y detalles completos.
          </div>
        </div>
      </div>

      {/* REACTION DETAIL MODAL (AMPLIAR) */}
      <ReactionDetailModal
        reaction={selectedReactionForDetail}
        onClose={() => setSelectedReactionForDetail(null)}
        onEdit={(reaction) => {
          setSelectedReactionForDetail(null);
          onEdit(reaction);
        }}
        onDelete={(id) => {
          setSelectedReactionForDetail(null);
          onDelete(id);
        }}
      />

      {/* PHOTO LIGHTBOX MODAL WITH MOBILE PINCH & DESKTOP ZOOM */}
      <PhotoLightboxModal
        imageUrl={previewPhotoUrl}
        onClose={() => setPreviewPhotoUrl(null)}
        title="Fotografía del brote alérgico"
      />
    </div>
  );
};
