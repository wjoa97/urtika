import React, { useState, useMemo } from 'react';
import { BODY_REGIONS } from './BodyMap';
import { useTheme } from '../theme/ThemeContext';

interface MiniBodyPreviewProps {
  selectedRegions?: string[];
  ubicacionCuerpo?: string;
  className?: string;
}

export const MiniBodyPreview: React.FC<MiniBodyPreviewProps> = ({
  selectedRegions = [],
  ubicacionCuerpo = '',
  className = '',
}) => {
  const { isDark } = useTheme();

  // Infer active regions: from selectedRegions array, or fallback by parsing text keywords
  const activeRegions = useMemo(() => {
    const set = new Set<string>(selectedRegions || []);

    if (set.size === 0 && ubicacionCuerpo) {
      const lower = ubicacionCuerpo.toLowerCase();
      if (lower.includes('cara') || lower.includes('cabeza') || lower.includes('frente') || lower.includes('mejilla')) {
        set.add('cara');
      }
      if (lower.includes('cuello')) set.add('cuello');
      if (lower.includes('pecho') || lower.includes('tórax') || lower.includes('torax')) set.add('pecho');
      if (lower.includes('abdomen') || lower.includes('barriga') || lower.includes('vientre')) set.add('abdomen');
      if (lower.includes('espalda alta') || (lower.includes('espalda') && !lower.includes('baja') && !lower.includes('lumbar'))) {
        set.add('espalda_alta');
      }
      if (lower.includes('espalda baja') || lower.includes('lumbar')) set.add('espalda_baja');
      if (lower.includes('glúteo') || lower.includes('gluteo') || lower.includes('nalga')) set.add('gluteos');
      
      // Arms
      if (lower.includes('brazo izq') || (lower.includes('brazo') && lower.includes('izquierdo'))) set.add('brazo_izq');
      else if (lower.includes('brazo der') || (lower.includes('brazo') && lower.includes('derecho'))) set.add('brazo_der');
      else if (lower.includes('brazo')) {
        set.add('brazo_izq');
        set.add('brazo_der');
      }

      if (lower.includes('codo izq') || (lower.includes('codo') && lower.includes('izquierdo'))) set.add('codo_izq');
      else if (lower.includes('codo der') || (lower.includes('codo') && lower.includes('derecho'))) set.add('codo_der');
      else if (lower.includes('codo')) {
        set.add('codo_izq');
        set.add('codo_der');
      }

      if (lower.includes('antebrazo izq')) set.add('antebrazo_izq');
      else if (lower.includes('antebrazo der')) set.add('antebrazo_der');
      else if (lower.includes('antebrazo')) {
        set.add('antebrazo_izq');
        set.add('antebrazo_der');
      }

      if (lower.includes('hombro izq')) set.add('hombro_izq');
      else if (lower.includes('hombro der')) set.add('hombro_der');
      else if (lower.includes('hombro')) {
        set.add('hombro_izq');
        set.add('hombro_der');
      }

      if (lower.includes('mano') || lower.includes('dedo')) set.add('manos');

      // Legs
      if (lower.includes('muslo izq')) set.add('muslo_izq');
      else if (lower.includes('muslo der')) set.add('muslo_der');
      else if (lower.includes('muslo')) {
        set.add('muslo_izq');
        set.add('muslo_der');
      }

      if (lower.includes('rodilla izq')) set.add('rodilla_izq');
      else if (lower.includes('rodilla der')) set.add('rodilla_der');
      else if (lower.includes('rodilla')) {
        set.add('rodilla_izq');
        set.add('rodilla_der');
      }

      if (lower.includes('pierna izq') || lower.includes('gemelo izq')) set.add('pierna_izq');
      else if (lower.includes('pierna der') || lower.includes('gemelo der')) set.add('pierna_der');
      else if (lower.includes('pierna') || lower.includes('gemelo')) {
        set.add('pierna_izq');
        set.add('pierna_der');
      }

      if (lower.includes('pie') || lower.includes('tobillo')) set.add('pies');
    }

    return set;
  }, [selectedRegions, ubicacionCuerpo]);

  // Color helpers
  const getFill = (id: string) => {
    if (activeRegions.has(id)) return '#f43f5e'; // rose-500 if active
    return isDark ? '#17212b' : '#f8fafc';
  };

  const getStroke = (id: string) => {
    if (activeRegions.has(id)) return '#be123c'; // rose-700 if active
    return isDark ? '#3a4b60' : '#cbd5e1';
  };

  // Names of active regions
  const activeRegionNames = useMemo(() => {
    return Array.from(activeRegions)
      .map((id) => BODY_REGIONS.find((r) => r.id === id)?.name || id)
      .filter(Boolean);
  }, [activeRegions]);

  return (
    <div className={`p-3 bg-white dark:bg-[#17212b] border border-slate-200 dark:border-[#1e2c3a] rounded-xl shadow-2xs space-y-2 ${className}`}>
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-bold text-slate-700 dark:text-[#f5f5f5] uppercase tracking-wide flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
          Mapa Anatómico del Brote
        </span>
        <span className="text-[10px] font-semibold text-slate-500 dark:text-[#7f91a4] bg-slate-100 dark:bg-[#242f3d] px-2 py-0.5 rounded-full">
          {activeRegions.size > 0 ? `${activeRegions.size} zona(s) afectada(s)` : 'Sin zonas marcadas'}
        </span>
      </div>

      {/* Side-by-Side Dual Silhouettes: Frente & Espalda */}
      <div className="grid grid-cols-2 gap-2 bg-slate-50/70 dark:bg-[#1e2c3a]/70 p-2 rounded-xl border border-slate-100 dark:border-[#2b394a]">
        {/* Front View */}
        <div className="flex flex-col items-center">
          <span className="text-[10px] font-bold text-slate-500 dark:text-[#7f91a4] uppercase mb-1">
            Frente
          </span>
          <svg
            viewBox="0 0 200 350"
            className="w-24 h-44 drop-shadow-xs select-none"
            aria-label="Silueta frontal"
          >
            <g id="mini-front-body">
              {/* Head / Face */}
              <circle
                cx="100"
                cy="32"
                r="20"
                fill={getFill('cara')}
                stroke={getStroke('cara')}
                strokeWidth="2"
              />
              {/* Neck */}
              <rect
                x="93"
                y="52"
                width="14"
                height="12"
                rx="3"
                fill={getFill('cuello')}
                stroke={getStroke('cuello')}
                strokeWidth="2"
              />
              {/* Chest */}
              <path
                d="M 68 66 L 132 66 L 126 105 L 74 105 Z"
                fill={getFill('pecho')}
                stroke={getStroke('pecho')}
                strokeWidth="2"
              />
              {/* Abdomen */}
              <path
                d="M 74 107 L 126 107 L 122 145 L 78 145 Z"
                fill={getFill('abdomen')}
                stroke={getStroke('abdomen')}
                strokeWidth="2"
              />
              {/* Left Shoulder (anatomical left = viewer right) */}
              <path
                d="M 132 66 C 145 68, 150 78, 148 90 L 132 85 Z"
                fill={getFill('hombro_izq')}
                stroke={getStroke('hombro_izq')}
                strokeWidth="2"
              />
              {/* Right Shoulder */}
              <path
                d="M 68 66 C 55 68, 50 78, 52 90 L 68 85 Z"
                fill={getFill('hombro_der')}
                stroke={getStroke('hombro_der')}
                strokeWidth="2"
              />
              {/* Right Arm */}
              <rect
                x="45"
                y="92"
                width="18"
                height="34"
                rx="6"
                fill={getFill('brazo_der')}
                stroke={getStroke('brazo_der')}
                strokeWidth="2"
              />
              {/* Right Elbow */}
              <rect
                x="43"
                y="128"
                width="18"
                height="16"
                rx="4"
                fill={getFill('codo_der')}
                stroke={getStroke('codo_der')}
                strokeWidth="2"
              />
              {/* Right Forearm */}
              <rect
                x="40"
                y="146"
                width="17"
                height="36"
                rx="5"
                fill={getFill('antebrazo_der')}
                stroke={getStroke('antebrazo_der')}
                strokeWidth="2"
              />
              {/* Right Hand */}
              <circle
                cx="46"
                cy="192"
                r="9"
                fill={getFill('manos')}
                stroke={getStroke('manos')}
                strokeWidth="2"
              />
              {/* Left Arm */}
              <rect
                x="137"
                y="92"
                width="18"
                height="34"
                rx="6"
                fill={getFill('brazo_izq')}
                stroke={getStroke('brazo_izq')}
                strokeWidth="2"
              />
              {/* Left Elbow */}
              <rect
                x="139"
                y="128"
                width="18"
                height="16"
                rx="4"
                fill={getFill('codo_izq')}
                stroke={getStroke('codo_izq')}
                strokeWidth="2"
              />
              {/* Left Forearm */}
              <rect
                x="143"
                y="146"
                width="17"
                height="36"
                rx="5"
                fill={getFill('antebrazo_izq')}
                stroke={getStroke('antebrazo_izq')}
                strokeWidth="2"
              />
              {/* Left Hand */}
              <circle
                cx="154"
                cy="192"
                r="9"
                fill={getFill('manos')}
                stroke={getStroke('manos')}
                strokeWidth="2"
              />
              {/* Pelvis Area */}
              <path
                d="M 78 147 L 122 147 L 118 168 L 82 168 Z"
                fill={isDark ? '#1e2c3a' : '#e2e8f0'}
                stroke={isDark ? '#3a4b60' : '#cbd5e1'}
                strokeWidth="1.5"
              />
              {/* Right Thigh */}
              <path
                d="M 76 170 L 97 170 L 95 230 L 73 230 Z"
                fill={getFill('muslo_der')}
                stroke={getStroke('muslo_der')}
                strokeWidth="2"
              />
              {/* Left Thigh */}
              <path
                d="M 103 170 L 124 170 L 127 230 L 105 230 Z"
                fill={getFill('muslo_izq')}
                stroke={getStroke('muslo_izq')}
                strokeWidth="2"
              />
              {/* Knees */}
              <circle
                cx="84"
                cy="240"
                r="9"
                fill={getFill('rodilla_der')}
                stroke={getStroke('rodilla_der')}
                strokeWidth="2"
              />
              <circle
                cx="116"
                cy="240"
                r="9"
                fill={getFill('rodilla_izq')}
                stroke={getStroke('rodilla_izq')}
                strokeWidth="2"
              />
              {/* Right Leg */}
              <rect
                x="75"
                y="252"
                width="18"
                height="65"
                rx="6"
                fill={getFill('pierna_der')}
                stroke={getStroke('pierna_der')}
                strokeWidth="2"
              />
              {/* Left Leg */}
              <rect
                x="107"
                y="252"
                width="18"
                height="65"
                rx="6"
                fill={getFill('pierna_izq')}
                stroke={getStroke('pierna_izq')}
                strokeWidth="2"
              />
              {/* Feet */}
              <path
                d="M 70 320 C 70 320, 78 335, 93 335 L 72 335 Z"
                fill={getFill('pies')}
                stroke={getStroke('pies')}
                strokeWidth="2"
              />
              <path
                d="M 130 320 C 130 320, 122 335, 107 335 L 128 335 Z"
                fill={getFill('pies')}
                stroke={getStroke('pies')}
                strokeWidth="2"
              />
            </g>
          </svg>
        </div>

        {/* Back View */}
        <div className="flex flex-col items-center">
          <span className="text-[10px] font-bold text-slate-500 uppercase mb-1">
            Espalda
          </span>
          <svg
            viewBox="0 0 200 350"
            className="w-24 h-44 drop-shadow-xs select-none"
            aria-label="Silueta dorsal"
          >
            <g id="mini-back-body">
              {/* Back of Head */}
              <circle
                cx="100"
                cy="32"
                r="20"
                fill={getFill('cara')}
                stroke={getStroke('cara')}
                strokeWidth="2"
              />
              {/* Neck */}
              <rect
                x="93"
                y="52"
                width="14"
                height="12"
                rx="3"
                fill={getFill('cuello')}
                stroke={getStroke('cuello')}
                strokeWidth="2"
              />
              {/* Upper Back */}
              <path
                d="M 68 66 L 132 66 L 126 108 L 74 108 Z"
                fill={getFill('espalda_alta')}
                stroke={getStroke('espalda_alta')}
                strokeWidth="2"
              />
              {/* Lower Back / Lumbar */}
              <path
                d="M 74 110 L 126 110 L 122 138 L 78 138 Z"
                fill={getFill('espalda_baja')}
                stroke={getStroke('espalda_baja')}
                strokeWidth="2"
              />
              {/* Gluteus */}
              <path
                d="M 78 140 L 122 140 L 125 168 L 75 168 Z"
                fill={getFill('gluteos')}
                stroke={getStroke('gluteos')}
                strokeWidth="2"
              />
              {/* Left Shoulder (back view: left is anatomical left) */}
              <path
                d="M 68 66 C 55 68, 50 78, 52 90 L 68 85 Z"
                fill={getFill('hombro_izq')}
                stroke={getStroke('hombro_izq')}
                strokeWidth="2"
              />
              {/* Right Shoulder */}
              <path
                d="M 132 66 C 145 68, 150 78, 148 90 L 132 85 Z"
                fill={getFill('hombro_der')}
                stroke={getStroke('hombro_der')}
                strokeWidth="2"
              />
              {/* Left Arm */}
              <rect
                x="45"
                y="92"
                width="18"
                height="34"
                rx="6"
                fill={getFill('brazo_izq')}
                stroke={getStroke('brazo_izq')}
                strokeWidth="2"
              />
              {/* Left Elbow */}
              <rect
                x="43"
                y="128"
                width="18"
                height="16"
                rx="4"
                fill={getFill('codo_izq')}
                stroke={getStroke('codo_izq')}
                strokeWidth="2"
              />
              {/* Left Forearm */}
              <rect
                x="40"
                y="146"
                width="17"
                height="36"
                rx="5"
                fill={getFill('antebrazo_izq')}
                stroke={getStroke('antebrazo_izq')}
                strokeWidth="2"
              />
              {/* Left Hand */}
              <circle
                cx="46"
                cy="192"
                r="9"
                fill={getFill('manos')}
                stroke={getStroke('manos')}
                strokeWidth="2"
              />
              {/* Right Arm */}
              <rect
                x="137"
                y="92"
                width="18"
                height="34"
                rx="6"
                fill={getFill('brazo_der')}
                stroke={getStroke('brazo_der')}
                strokeWidth="2"
              />
              {/* Right Elbow */}
              <rect
                x="139"
                y="128"
                width="18"
                height="16"
                rx="4"
                fill={getFill('codo_der')}
                stroke={getStroke('codo_der')}
                strokeWidth="2"
              />
              {/* Right Forearm */}
              <rect
                x="143"
                y="146"
                width="17"
                height="36"
                rx="5"
                fill={getFill('antebrazo_der')}
                stroke={getStroke('antebrazo_der')}
                strokeWidth="2"
              />
              {/* Right Hand */}
              <circle
                cx="154"
                cy="192"
                r="9"
                fill={getFill('manos')}
                stroke={getStroke('manos')}
                strokeWidth="2"
              />
              {/* Left Thigh (back) */}
              <path
                d="M 76 170 L 97 170 L 95 230 L 73 230 Z"
                fill={getFill('muslo_izq')}
                stroke={getStroke('muslo_izq')}
                strokeWidth="2"
              />
              {/* Right Thigh (back) */}
              <path
                d="M 103 170 L 124 170 L 127 230 L 105 230 Z"
                fill={getFill('muslo_der')}
                stroke={getStroke('muslo_der')}
                strokeWidth="2"
              />
              {/* Knees / Popliteal fossa */}
              <circle
                cx="84"
                cy="240"
                r="9"
                fill={getFill('rodilla_izq')}
                stroke={getStroke('rodilla_izq')}
                strokeWidth="2"
              />
              <circle
                cx="116"
                cy="240"
                r="9"
                fill={getFill('rodilla_der')}
                stroke={getStroke('rodilla_der')}
                strokeWidth="2"
              />
              {/* Left Calf */}
              <rect
                x="75"
                y="252"
                width="18"
                height="65"
                rx="6"
                fill={getFill('pierna_izq')}
                stroke={getStroke('pierna_izq')}
                strokeWidth="2"
              />
              {/* Right Calf */}
              <rect
                x="107"
                y="252"
                width="18"
                height="65"
                rx="6"
                fill={getFill('pierna_der')}
                stroke={getStroke('pierna_der')}
                strokeWidth="2"
              />
              {/* Feet */}
              <path
                d="M 72 320 L 92 320 L 92 335 L 72 335 Z"
                fill={getFill('pies')}
                stroke={getStroke('pies')}
                strokeWidth="2"
              />
              <path
                d="M 108 320 L 128 320 L 128 335 L 108 335 Z"
                fill={getFill('pies')}
                stroke={getStroke('pies')}
                strokeWidth="2"
              />
            </g>
          </svg>
        </div>
      </div>

      {/* Affected region tags list */}
      {activeRegionNames.length > 0 && (
        <div className="flex flex-wrap gap-1 pt-1">
          {activeRegionNames.map((name) => (
            <span
              key={name}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-50 dark:bg-rose-950/50 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-900 text-[11px] font-semibold"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-rose-600 dark:bg-rose-400"></span>
              {name}
            </span>
          ))}
        </div>
      )}
    </div>
  );
};
