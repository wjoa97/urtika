import React, { useState, useEffect } from 'react';
import {
  X,
  Clock,
  Sparkles,
  Play,
  Square,
  AlertCircle,
  Pill,
  MapPin,
  Calendar,
  Camera,
  Image as ImageIcon,
  Trash2,
} from 'lucide-react';
import { AllergyReaction } from '../types/allergy';
import { BodyMap } from './BodyMap';
import {
  getISOWeekNumber,
  formatDateToSpreadsheet,
  formatDateToInput,
  formatSecondsToDurationString,
  getUASLevel,
} from '../utils/dateAndUas';
import { PhotoLightboxModal } from './PhotoLightboxModal';

interface ReactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (reaction: AllergyReaction) => void;
  initialData?: AllergyReaction | null;
}

const COMMON_LOCATIONS = [
  'Oficina',
  'Casa',
  'Trabajo',
  'Restaurante',
  'Calle / Exterior',
  'Gimnasio',
  'Coche',
  'Viaje',
];

const COMMON_MEDICATIONS = [
  'Ebastina 10mg',
  'Ebastina 20mg',
  'Bilastina 20mg',
  'Cetirizina 10mg',
  'Desloratadina 5mg',
  'Loratadina 10mg',
  'Polaramine',
  'Prednisona 20mg',
  'Crema corticoide',
];

const DURATION_PRESETS = [
  { label: '10 min', value: '0:10:00' },
  { label: '12 min', value: '0:12:00' },
  { label: '15 min', value: '0:15:00' },
  { label: '20 min', value: '0:20:00' },
  { label: '30 min', value: '0:30:00' },
  { label: '45 min', value: '0:45:00' },
  { label: '1 hora', value: '1:00:00' },
  { label: '2 horas', value: '2:00:00' },
];

const COMMON_TRIGGERS = [
  'Comida / Alimento',
  'Estrés laboral',
  'Calor / Ducha caliente',
  'Frío',
  'Sudor / Ejercicio',
  'Roce con ropa',
  'Contacto químico',
  'Picadura',
];

export const ReactionModal: React.FC<ReactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialData,
}) => {
  const [fechaInput, setFechaInput] = useState<string>('');
  const [semana, setSemana] = useState<number>(1);
  const [ubicacion, setUbicacion] = useState<string>('');
  const [ubicacionCuerpo, setUbicacionCuerpo] = useState<string>('');
  const [cuerpoZonas, setCuerpoZonas] = useState<string[]>([]);
  const [ronchas, setRonchas] = useState<number>(1);
  const [prurito, setPrurito] = useState<number>(1);
  const [tomoMedicamento, setTomoMedicamento] = useState<boolean>(false);
  const [medicamento, setMedicamento] = useState<string>('');
  const [tiempoDesaparecer, setTiempoDesaparecer] = useState<string>('');
  const [notas, setNotas] = useState<string>('');
  const [detonantes, setDetonantes] = useState<string[]>([]);
  const [fotos, setFotos] = useState<string[]>([]);
  const [previewPhotoUrl, setPreviewPhotoUrl] = useState<string | null>(null);

  // Stopwatch state for live disappearing measurement
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [timerSeconds, setTimerSeconds] = useState<number>(0);

  // Initialize form state
  useEffect(() => {
    if (!isOpen) {
      setIsTimerRunning(false);
      return;
    }

    if (initialData) {
      setFechaInput(initialData.fecha);
      setSemana(initialData.semana);
      setUbicacion(initialData.ubicacion || '');
      setUbicacionCuerpo(initialData.ubicacionCuerpo || '');
      setCuerpoZonas(initialData.cuerpoZonasSeleccionadas || []);
      setRonchas(initialData.ronchas ?? 1);
      setPrurito(initialData.prurito ?? 1);
      setTomoMedicamento(Boolean(initialData.tomoMedicamento));
      setMedicamento(initialData.medicamento || '');
      setTiempoDesaparecer(initialData.tiempoDesaparecer || '');
      setNotas(initialData.notas || '');
      setDetonantes(initialData.detonantes || []);
      setFotos(initialData.fotos || []);
    } else {
      // Default to now
      const now = new Date();
      const inputStr = formatDateToInput(now);
      setFechaInput(inputStr);
      setSemana(getISOWeekNumber(now));
      setUbicacion('');
      setUbicacionCuerpo('');
      setCuerpoZonas([]);
      setRonchas(1);
      setPrurito(1);
      setTomoMedicamento(false);
      setMedicamento('');
      setTiempoDesaparecer('');
      setNotas('');
      setDetonantes([]);
      setFotos([]);
    }
  }, [isOpen, initialData]);

  // Recalculate week when date changes
  const handleDateChange = (newVal: string) => {
    setFechaInput(newVal);
    if (newVal) {
      const calculatedWeek = getISOWeekNumber(newVal);
      setSemana(calculatedWeek);
    }
  };

  const handleSetCurrentDate = () => {
    const now = new Date();
    setFechaInput(formatDateToInput(now));
    setSemana(getISOWeekNumber(now));
  };

  // Stopwatch effect
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning]);

  const handleStopTimer = () => {
    setIsTimerRunning(false);
    const formatted = formatSecondsToDurationString(timerSeconds);
    setTiempoDesaparecer(formatted);
  };

  const handleStartTimer = () => {
    setTimerSeconds(0);
    setIsTimerRunning(true);
  };

  const handleToggleTrigger = (trigger: string) => {
    if (detonantes.includes(trigger)) {
      setDetonantes(detonantes.filter((t) => t !== trigger));
    } else {
      setDetonantes([...detonantes, trigger]);
      // Also optionally append to notes if not already mentioned
      if (!notas.includes(trigger)) {
        setNotas((prev) => (prev ? `${prev}. Detonante sospechoso: ${trigger}` : `Detonante sospechoso: ${trigger}`));
      }
    }
  };

  // UAS calculation: Ronchas + Prurito
  const puntuacionDia = ronchas + prurito;
  const uasInfo = getUASLevel(puntuacionDia);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const dateObj = new Date(fechaInput);
    const formatted = formatDateToSpreadsheet(dateObj);

    const record: AllergyReaction = {
      id: initialData?.id || `rec-${Date.now()}`,
      fecha: fechaInput,
      fechaFormateada: formatted,
      semana: semana || getISOWeekNumber(dateObj),
      ubicacion: ubicacion.trim(),
      ubicacionCuerpo: ubicacionCuerpo.trim(),
      cuerpoZonasSeleccionadas: cuerpoZonas,
      ronchas,
      prurito,
      puntuacionDia,
      tomoMedicamento,
      medicamento: tomoMedicamento ? medicamento.trim() : '',
      tiempoDesaparecer: tiempoDesaparecer.trim(),
      notas: notas.trim(),
      detonantes,
      fotos,
      creadoEn: initialData?.creadoEn || new Date().toISOString(),
    };

    onSave(record);
    onClose();
  };

  // Handle Photo selection from camera or gallery with automatic client-side compression
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          // Resize and compress to keep localStorage lightweight and fast
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const maxDim = 800;

          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const compressedBase64 = canvas.toDataURL('image/jpeg', 0.75);
            setFotos((prev) => [...prev, compressedBase64]);
          }
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    });

    e.target.value = '';
  };

  const handleRemovePhoto = (indexToRemove: number) => {
    setFotos((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 dark:bg-black/75 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white dark:bg-[#242f3d] rounded-2xl shadow-2xl border border-slate-200 dark:border-[#1e2c3a] overflow-hidden my-6">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-[#1e2c3a] bg-slate-50/70 dark:bg-[#17212b]">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-[#f5f5f5]">
              {initialData ? 'Editar Reacción Alérgica' : 'Registrar Nueva Reacción Alérgica'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-[#7f91a4] mt-0.5">
              Rellena de forma guiada los datos para tu hoja de registro clínico y UAS7
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 dark:text-[#7f91a4] hover:text-slate-700 dark:hover:text-[#f5f5f5] hover:bg-slate-200/60 dark:hover:bg-[#2b394a] rounded-lg transition-colors"
            title="Cerrar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[82vh] overflow-y-auto custom-scrollbar">
          {/* Step 1: Momento y Ubicación Ambiental */}
          <div className="space-y-3 p-4 bg-slate-50/50 dark:bg-[#17212b]/80 rounded-xl border border-slate-200/70 dark:border-[#1e2c3a]">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-[#f5f5f5] uppercase tracking-wide flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-slate-600 dark:text-[#7f91a4]" />
                1. Momento y Entorno
              </span>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-200/80 dark:bg-[#242f3d] text-slate-800 dark:text-[#f5f5f5]">
                  Semana {semana}
                </span>
                <button
                  type="button"
                  onClick={handleSetCurrentDate}
                  className="text-xs text-rose-600 dark:text-[#64b5f6] hover:text-rose-700 font-semibold underline"
                >
                  Poner ahora mismo
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-[#7f91a4] mb-1">
                  Fecha y Hora
                </label>
                <input
                  type="datetime-local"
                  required
                  value={fechaInput}
                  onChange={(e) => handleDateChange(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-[#242f3d] border border-slate-300 dark:border-[#1e2c3a] text-slate-900 dark:text-[#f5f5f5] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5288c1] font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-[#7f91a4] mb-1 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-500 dark:text-[#7f91a4]" />
                  ¿Dónde estás? (Ubicación)
                </label>
                <input
                  type="text"
                  value={ubicacion}
                  onChange={(e) => setUbicacion(e.target.value)}
                  placeholder="Ej: Oficina, Casa, Gimnasio..."
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-[#242f3d] border border-slate-300 dark:border-[#1e2c3a] text-slate-900 dark:text-[#f5f5f5] placeholder:text-slate-400 dark:placeholder:text-[#7f91a4] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5288c1]"
                />
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {COMMON_LOCATIONS.map((loc) => (
                    <button
                      key={loc}
                      type="button"
                      onClick={() => setUbicacion(loc)}
                      className={`text-[11px] px-2 py-0.5 rounded-md border transition-colors ${
                        ubicacion === loc
                          ? 'bg-slate-900 dark:bg-[#5288c1] text-white border-slate-900 dark:border-[#5288c1] font-medium'
                          : 'bg-white dark:bg-[#242f3d] text-slate-600 dark:text-[#7f91a4] border-slate-200 dark:border-[#1e2c3a] hover:bg-slate-100 dark:hover:bg-[#2b394a]'
                      }`}
                    >
                      {loc}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Step 2: Ubicación en el Cuerpo */}
          <div className="space-y-3 p-4 bg-slate-50/50 dark:bg-[#17212b]/80 rounded-xl border border-slate-200/70 dark:border-[#1e2c3a]">
            <span className="text-xs font-bold text-slate-900 dark:text-[#f5f5f5] uppercase tracking-wide block">
              2. Ubicación en el Cuerpo (UbicaciónCuerpo)
            </span>
            <BodyMap
              selectedRegions={cuerpoZonas}
              onChange={(regions, suggested) => {
                setCuerpoZonas(regions);
                if (suggested && (!ubicacionCuerpo || ubicacionCuerpo.trim() === '')) {
                  setUbicacionCuerpo(suggested);
                } else if (suggested) {
                  setUbicacionCuerpo(suggested);
                }
              }}
              customText={ubicacionCuerpo}
              onCustomTextChange={(txt) => setUbicacionCuerpo(txt)}
            />
          </div>

          {/* Step 3: Evaluación UAS (Ronchas + Prurito = Puntuación Día) */}
          <div className="space-y-4 p-4 bg-slate-50/50 dark:bg-[#17212b]/80 rounded-xl border border-slate-200/70 dark:border-[#1e2c3a]">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-[#f5f5f5] uppercase tracking-wide">
                3. Intensidad Clínica (Escala Estándar UAS 0-3)
              </span>
              <div
                className={`text-xs px-3 py-1 font-bold rounded-lg border flex items-center gap-1.5 ${uasInfo.badgeClass}`}
              >
                <span>Puntuación Día: {puntuacionDia} / 6</span>
                <span>·</span>
                <span>{uasInfo.label}</span>
              </div>
            </div>

            {/* Nº de Ronchas */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-800 dark:text-[#f5f5f5]">
                  Nº Ronchas / Habones (0-3)
                </label>
                <span className="text-xs text-slate-500 dark:text-[#7f91a4] font-mono font-medium">
                  Seleccionado: {ronchas}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { value: 0, title: '0 - Ninguna', desc: 'Sin ronchas ni habones' },
                  { value: 1, title: '1 - Leve', desc: '< 20 ronchas en 24h' },
                  { value: 2, title: '2 - Moderado', desc: '20 a 50 ronchas' },
                  { value: 3, title: '3 - Intenso', desc: '> 50 ronchas o placas confluentes' },
                ].map((item) => (
                  <button
                    key={item.value}
                    type="button"
                    onClick={() => setRonchas(item.value)}
                    className={`p-2.5 rounded-xl text-left border transition-all ${
                      ronchas === item.value
                        ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-400 dark:border-rose-700 text-rose-950 dark:text-rose-200 ring-2 ring-rose-200 dark:ring-rose-900 font-semibold'
                        : 'bg-white dark:bg-[#242f3d] border-slate-200 dark:border-[#1e2c3a] text-slate-700 dark:text-[#f5f5f5] hover:border-slate-300 dark:hover:border-[#2b394a]'
                    }`}
                  >
                    <div className="text-xs font-bold text-slate-900 dark:text-[#f5f5f5] mb-0.5">{item.title}</div>
                    <div className="text-[11px] text-slate-500 dark:text-[#7f91a4] line-clamp-2">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Prurito / Picor */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-800 dark:text-[#f5f5f5]">
                  Prurito / Picazón (0-3)
                </label>
                <span className="text-xs text-slate-500 dark:text-[#7f91a4] font-mono font-medium">
                  Seleccionado: {prurito}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { value: 0, title: '0 - Ninguno', desc: 'No pica en absoluto' },
                  { value: 1, title: '1 - Leve', desc: 'Presente pero no molesto' },
                  { value: 2, title: '2 - Moderado', desc: 'Molesto, no interfiere con el día' },
                  { value: 3, title: '3 - Intenso', desc: 'Severo, interfiere con sueño/tareas' },
                ].map((item) => (
                  <button
                    key={item.value}
                    type="button"
                    onClick={() => setPrurito(item.value)}
                    className={`p-2.5 rounded-xl text-left border transition-all ${
                      prurito === item.value
                        ? 'bg-amber-50 dark:bg-amber-950/60 border-amber-400 dark:border-amber-700 text-amber-950 dark:text-amber-200 ring-2 ring-amber-200 dark:ring-amber-900 font-semibold'
                        : 'bg-white dark:bg-[#242f3d] border-slate-200 dark:border-[#1e2c3a] text-slate-700 dark:text-[#f5f5f5] hover:border-slate-300 dark:hover:border-[#2b394a]'
                    }`}
                  >
                    <div className="text-xs font-bold text-slate-900 dark:text-[#f5f5f5] mb-0.5">{item.title}</div>
                    <div className="text-[11px] text-slate-500 dark:text-[#7f91a4] line-clamp-2">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Step 4: ¿Tomó medicamento? */}
          <div className="space-y-3 p-4 bg-slate-50/50 dark:bg-[#17212b]/80 rounded-xl border border-slate-200/70 dark:border-[#1e2c3a]">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-[#f5f5f5] uppercase tracking-wide flex items-center gap-1.5">
                <Pill className="w-4 h-4 text-slate-600 dark:text-[#7f91a4]" />
                4. Medicación
              </span>
              <div className="flex items-center gap-1 bg-slate-200/70 dark:bg-[#242f3d] p-0.5 rounded-lg">
                <button
                  type="button"
                  onClick={() => setTomoMedicamento(false)}
                  className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                    !tomoMedicamento
                      ? 'bg-white dark:bg-[#17212b] text-slate-900 dark:text-[#f5f5f5] shadow-xs'
                      : 'text-slate-600 dark:text-[#7f91a4] hover:text-slate-900 dark:hover:text-[#f5f5f5]'
                  }`}
                >
                  No tomé (NO)
                </button>
                <button
                  type="button"
                  onClick={() => setTomoMedicamento(true)}
                  className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                    tomoMedicamento
                      ? 'bg-white dark:bg-[#17212b] text-emerald-800 dark:text-emerald-300 shadow-xs'
                      : 'text-slate-600 dark:text-[#7f91a4] hover:text-slate-900 dark:hover:text-[#f5f5f5]'
                  }`}
                >
                  Sí tomé (SÍ)
                </button>
              </div>
            </div>

            {tomoMedicamento && (
              <div className="space-y-2 pt-2 animate-in fade-in duration-200">
                <label className="block text-xs font-semibold text-slate-700 dark:text-[#7f91a4]">
                  ¿Qué medicamento y dosis tomaste?
                </label>
                <input
                  type="text"
                  value={medicamento}
                  onChange={(e) => setMedicamento(e.target.value)}
                  placeholder="Ej: Ebastina 10mg / Bilastina 20mg / Prednisona..."
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-[#242f3d] border border-slate-300 dark:border-[#1e2c3a] text-slate-900 dark:text-[#f5f5f5] placeholder:text-slate-400 dark:placeholder:text-[#7f91a4] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5288c1]"
                />
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {COMMON_MEDICATIONS.map((med) => (
                    <button
                      key={med}
                      type="button"
                      onClick={() => setMedicamento(med)}
                      className={`text-xs px-2.5 py-1 rounded-md border transition-colors ${
                        medicamento === med
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-300 dark:border-emerald-700 font-semibold'
                          : 'bg-white dark:bg-[#242f3d] text-slate-600 dark:text-[#7f91a4] border-slate-200 dark:border-[#1e2c3a] hover:bg-slate-100 dark:hover:bg-[#2b394a]'
                      }`}
                    >
                      {med}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Step 5: Tiempo en desaparecer */}
          <div className="space-y-3 p-4 bg-slate-50/50 dark:bg-[#17212b]/80 rounded-xl border border-slate-200/70 dark:border-[#1e2c3a]">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-[#f5f5f5] uppercase tracking-wide flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-slate-600 dark:text-[#7f91a4]" />
                5. Tiempo en Desaparecer (hh:mm:ss)
              </span>
              {tiempoDesaparecer && (
                <button
                  type="button"
                  onClick={() => setTiempoDesaparecer('')}
                  className="text-xs text-slate-500 dark:text-[#7f91a4] hover:text-slate-700 dark:hover:text-[#f5f5f5] underline"
                >
                  Borrar tiempo
                </button>
              )}
            </div>

            {/* Live Stopwatch Toolbar */}
            <div className="flex flex-wrap items-center justify-between p-3 bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-xl gap-3">
              <div className="flex items-center gap-3">
                <div className="text-sm font-semibold text-slate-700 dark:text-[#7f91a4] flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
                  <span>Cronómetro en vivo:</span>
                </div>
                <div className="font-mono text-base font-bold text-slate-900 dark:text-[#f5f5f5] tabular-nums">
                  {formatSecondsToDurationString(timerSeconds) || '0:00:00'}
                </div>
              </div>

              <div className="flex items-center gap-2">
                {!isTimerRunning ? (
                  <button
                    type="button"
                    onClick={handleStartTimer}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 dark:text-[#f5f5f5] bg-slate-100 dark:bg-[#17212b] hover:bg-slate-200 dark:hover:bg-[#2b394a] rounded-lg transition-colors"
                  >
                    <Play className="w-3.5 h-3.5 text-slate-700 dark:text-[#7f91a4] fill-current" />
                    Iniciar medición
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleStopTimer}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors shadow-xs"
                  >
                    <Square className="w-3.5 h-3.5 fill-white" />
                    Ha desaparecido (Guardar tiempo)
                  </button>
                )}
              </div>
            </div>

            {/* Quick Presets & Manual Input */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
              <div className="sm:col-span-8">
                <span className="text-[11px] font-semibold text-slate-500 dark:text-[#7f91a4] block mb-1">
                  Tiempos habituales en tu registro:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {DURATION_PRESETS.map((dp) => (
                    <button
                      key={dp.value}
                      type="button"
                      onClick={() => setTiempoDesaparecer(dp.value)}
                      className={`text-xs px-2.5 py-1 rounded-md border font-mono tabular-nums transition-colors ${
                        tiempoDesaparecer === dp.value
                          ? 'bg-slate-900 dark:bg-[#5288c1] text-white border-slate-900 dark:border-[#5288c1] font-semibold'
                          : 'bg-white dark:bg-[#242f3d] text-slate-700 dark:text-[#7f91a4] border-slate-200 dark:border-[#1e2c3a] hover:bg-slate-100 dark:hover:bg-[#2b394a]'
                      }`}
                    >
                      {dp.label} ({dp.value})
                    </button>
                  ))}
                </div>
              </div>

              <div className="sm:col-span-4">
                <label className="block text-[11px] font-semibold text-slate-500 dark:text-[#7f91a4] mb-1">
                  O escribe formato exacto (H:MM:SS):
                </label>
                <input
                  type="text"
                  value={tiempoDesaparecer}
                  onChange={(e) => setTiempoDesaparecer(e.target.value)}
                  placeholder="0:15:00"
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white dark:bg-[#242f3d] border border-slate-300 dark:border-[#1e2c3a] text-slate-900 dark:text-[#f5f5f5] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5288c1]"
                />
              </div>
            </div>
          </div>

          {/* Step 6: Notas y Posibles Detonantes */}
          <div className="space-y-3 p-4 bg-slate-50/50 dark:bg-[#17212b]/80 rounded-xl border border-slate-200/70 dark:border-[#1e2c3a]">
            <span className="text-xs font-bold text-slate-900 dark:text-[#f5f5f5] uppercase tracking-wide block">
              6. Notas y Factores Desencadenantes
            </span>

            {/* Quick triggers */}
            <div>
              <span className="text-[11px] font-semibold text-slate-500 dark:text-[#7f91a4] block mb-1">
                ¿Qué crees que pudo causarlo? (Añadir a notas):
              </span>
              <div className="flex flex-wrap gap-1.5">
                {COMMON_TRIGGERS.map((trigger) => {
                  const active = detonantes.includes(trigger);
                  return (
                    <button
                      key={trigger}
                      type="button"
                      onClick={() => handleToggleTrigger(trigger)}
                      className={`text-xs px-2.5 py-1 rounded-md border transition-colors ${
                        active
                          ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border-rose-300 dark:border-rose-700 font-semibold'
                          : 'bg-white dark:bg-[#242f3d] text-slate-600 dark:text-[#7f91a4] border-slate-200 dark:border-[#1e2c3a] hover:bg-slate-100 dark:hover:bg-[#2b394a]'
                      }`}
                    >
                      {trigger}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-[#7f91a4] mb-1">
                Notas y observaciones
              </label>
              <textarea
                rows={2}
                value={notas}
                onChange={(e) => setNotas(e.target.value)}
                placeholder="Ej: Comenzó con picazón leve tras comida / ducha caliente..."
                className="w-full px-3 py-2 text-sm bg-white dark:bg-[#242f3d] border border-slate-300 dark:border-[#1e2c3a] text-slate-900 dark:text-[#f5f5f5] placeholder:text-slate-400 dark:placeholder:text-[#7f91a4] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5288c1]"
              />
            </div>
          </div>

          {/* Step 7: Fotos del Brote Alérgico (Cámara / Galería) */}
          <div className="space-y-3 p-4 bg-rose-50/40 dark:bg-rose-950/20 rounded-xl border border-rose-200/60 dark:border-rose-900/40">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-950 dark:text-rose-300 uppercase tracking-wide flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                7. Fotografías del Brote (Para el médico)
              </span>
              <span className="text-[11px] text-slate-500 dark:text-[#7f91a4]">
                {fotos.length} {fotos.length === 1 ? 'foto' : 'fotos'} adjuntas
              </span>
            </div>

            <p className="text-[11px] text-slate-500 dark:text-[#7f91a4]">
              Toma una foto con tu móvil o sube una imagen de la piel afectada. Se comprime automáticamente y se guarda en tu registro.
            </p>

            {/* Photo preview gallery */}
            {fotos.length > 0 && (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 pt-1">
                {fotos.map((foto, idx) => (
                  <div
                    key={idx}
                    className="relative group rounded-xl overflow-hidden border border-slate-200 dark:border-[#2b394a] aspect-square bg-slate-100 dark:bg-[#17212b] shadow-2xs"
                  >
                    <button
                      type="button"
                      onClick={() => setPreviewPhotoUrl(foto)}
                      className="w-full h-full cursor-pointer focus:outline-none"
                      title="Tocar para ampliar fotografía con zoom"
                    >
                      <img
                        src={foto}
                        alt={`Foto brote ${idx + 1}`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemovePhoto(idx);
                      }}
                      className="absolute top-1 right-1 p-1 rounded-full bg-rose-600 text-white shadow-xs opacity-90 hover:opacity-100 transition-opacity z-10"
                      title="Eliminar esta foto"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Upload Buttons */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <label className="inline-flex items-center gap-1.5 px-3 py-2 bg-white dark:bg-[#242f3d] hover:bg-slate-50 dark:hover:bg-[#2b394a] border border-slate-300 dark:border-[#1e2c3a] text-slate-700 dark:text-[#f5f5f5] text-xs font-semibold rounded-lg shadow-2xs cursor-pointer transition-colors">
                <Camera className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                <span>Tomar foto con cámara</span>
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>

              <label className="inline-flex items-center gap-1.5 px-3 py-2 bg-white dark:bg-[#242f3d] hover:bg-slate-50 dark:hover:bg-[#2b394a] border border-slate-300 dark:border-[#1e2c3a] text-slate-700 dark:text-[#f5f5f5] text-xs font-semibold rounded-lg shadow-2xs cursor-pointer transition-colors">
                <ImageIcon className="w-3.5 h-3.5 text-slate-500 dark:text-[#7f91a4]" />
                <span>Elegir de galería</span>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-[#1e2c3a]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-semibold text-slate-700 dark:text-[#7f91a4] hover:bg-slate-100 dark:hover:bg-[#2b394a] dark:hover:text-[#f5f5f5] rounded-xl transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-sm font-semibold text-white bg-slate-900 dark:bg-[#5288c1] hover:bg-slate-800 dark:hover:bg-[#64b5f6] rounded-xl transition-colors shadow-sm"
            >
              {initialData ? 'Guardar Cambios' : 'Registrar en la Hoja'}
            </button>
          </div>
        </form>
      </div>

      {/* PHOTO LIGHTBOX MODAL WITH MOBILE PINCH & DESKTOP ZOOM */}
      <PhotoLightboxModal
        imageUrl={previewPhotoUrl}
        onClose={() => setPreviewPhotoUrl(null)}
        title="Fotografía adjunta del brote"
      />
    </div>
  );
};
