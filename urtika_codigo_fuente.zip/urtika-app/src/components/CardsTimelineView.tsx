import React, { useState, useMemo } from 'react';
import {
  Clock,
  MapPin,
  Pill,
  Edit2,
  Trash2,
  CopyPlus,
  Activity,
  Plus,
  TrendingUp,
  Search,
  Filter,
  Calendar,
  X,
  Eye,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { AllergyReaction } from '../types/allergy';
import { getUASLevel } from '../utils/dateAndUas';
import { ReactionDetailModal } from './ReactionDetailModal';
import { PhotoLightboxModal } from './PhotoLightboxModal';

interface CardsTimelineViewProps {
  reactions: AllergyReaction[];
  onEdit: (reaction: AllergyReaction) => void;
  onDelete: (id: string) => void;
  onDuplicate: (reaction: AllergyReaction) => void;
  onAddNew: () => void;
}

export const CardsTimelineView: React.FC<CardsTimelineViewProps> = ({
  reactions,
  onEdit,
  onDelete,
  onDuplicate,
  onAddNew,
}) => {
  // Filter states
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedWeek, setSelectedWeek] = useState<string>('all');
  const [selectedTimePeriod, setSelectedTimePeriod] = useState<string>('all');
  const [customStartDate, setCustomStartDate] = useState<string>('');
  const [customEndDate, setCustomEndDate] = useState<string>('');
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState<boolean>(false);
  const [isChartVisible, setIsChartVisible] = useState<boolean>(true);

  // Detail Modal state
  const [selectedReactionForDetail, setSelectedReactionForDetail] =
    useState<AllergyReaction | null>(null);
  const [previewPhotoUrl, setPreviewPhotoUrl] = useState<string | null>(null);

  // Unique weeks
  const availableWeeks = useMemo(() => {
    return Array.from(new Set(reactions.map((r) => r.semana))).sort((a, b) => b - a);
  }, [reactions]);

  // Filtered reactions
  const filtered = useMemo(() => {
    return reactions.filter((r) => {
      // 1. Week Filter
      if (selectedWeek !== 'all' && String(r.semana) !== selectedWeek) {
        return false;
      }

      // 2. Predefined Time Period Filter
      const reactionDate = new Date(r.fecha);
      const now = new Date();

      if (selectedTimePeriod === 'today') {
        const isToday =
          reactionDate.getFullYear() === now.getFullYear() &&
          reactionDate.getMonth() === now.getMonth() &&
          reactionDate.getDate() === now.getDate();
        if (!isToday) return false;
      } else if (selectedTimePeriod === 'this_month') {
        const isThisMonth =
          reactionDate.getFullYear() === now.getFullYear() &&
          reactionDate.getMonth() === now.getMonth();
        if (!isThisMonth) return false;
      } else if (selectedTimePeriod === 'last_month') {
        const prevMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        const isLastMonth =
          reactionDate.getFullYear() === prevMonth.getFullYear() &&
          reactionDate.getMonth() === prevMonth.getMonth();
        if (!isLastMonth) return false;
      } else if (selectedTimePeriod === 'this_year') {
        if (reactionDate.getFullYear() !== now.getFullYear()) return false;
      } else if (selectedTimePeriod === 'last_7_days') {
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(now.getDate() - 7);
        if (reactionDate < sevenDaysAgo || reactionDate > now) return false;
      } else if (selectedTimePeriod === 'last_30_days') {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(now.getDate() - 30);
        if (reactionDate < thirtyDaysAgo || reactionDate > now) return false;
      }

      // 3. Custom Date Range
      if (customStartDate) {
        const start = new Date(customStartDate);
        start.setHours(0, 0, 0, 0);
        if (reactionDate < start) return false;
      }

      if (customEndDate) {
        const end = new Date(customEndDate);
        end.setHours(23, 59, 59, 999);
        if (reactionDate > end) return false;
      }

      // 4. Search query
      if (!searchTerm.trim()) return true;
      const term = searchTerm.toLowerCase();
      return (
        r.fechaFormateada.toLowerCase().includes(term) ||
        (r.ubicacion && r.ubicacion.toLowerCase().includes(term)) ||
        (r.ubicacionCuerpo && r.ubicacionCuerpo.toLowerCase().includes(term)) ||
        (r.medicamento && r.medicamento.toLowerCase().includes(term)) ||
        (r.notas && r.notas.toLowerCase().includes(term))
      );
    });
  }, [reactions, selectedWeek, selectedTimePeriod, customStartDate, customEndDate, searchTerm]);

  const clearAllFilters = () => {
    setSelectedWeek('all');
    setSelectedTimePeriod('all');
    setCustomStartDate('');
    setCustomEndDate('');
    setSearchTerm('');
  };

  const hasActiveFilters =
    selectedWeek !== 'all' ||
    selectedTimePeriod !== 'all' ||
    Boolean(customStartDate) ||
    Boolean(customEndDate) ||
    Boolean(searchTerm.trim());

  // Chronological sorting for the Line Chart (oldest to newest)
  const chronologicalData = useMemo(() => {
    return [...filtered].sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime());
  }, [filtered]);

  // Calculate SVG line points
  const chartHeight = 140;
  const chartPaddingTop = 20;
  const chartPaddingBottom = 30;
  const chartPaddingLeft = 35;
  const chartPaddingRight = 20;

  const chartPoints = useMemo(() => {
    if (chronologicalData.length < 2) return [];
    const width = 600; // Normalized virtual width
    const usableWidth = width - chartPaddingLeft - chartPaddingRight;
    const usableHeight = chartHeight - chartPaddingTop - chartPaddingBottom;

    return chronologicalData.map((d, index) => {
      const x = chartPaddingLeft + (index / (chronologicalData.length - 1)) * usableWidth;
      // y-scale: score 0 is at bottom (chartHeight - chartPaddingBottom), score 6 is at top (chartPaddingTop)
      const score = Math.min(6, Math.max(0, d.puntuacionDia));
      const y = chartHeight - chartPaddingBottom - (score / 6) * usableHeight;
      return { x, y, data: d };
    });
  }, [chronologicalData]);

  // SVG Path generator
  const linePath = useMemo(() => {
    if (chartPoints.length < 2) return '';
    return chartPoints.reduce((acc, point, index) => {
      if (index === 0) return `M ${point.x} ${point.y}`;
      // Gentle curve between points
      const prev = chartPoints[index - 1];
      const cx = (prev.x + point.x) / 2;
      return `${acc} C ${cx} ${prev.y}, ${cx} ${point.y}, ${point.x} ${point.y}`;
    }, '');
  }, [chartPoints]);

  const areaPath = useMemo(() => {
    if (chartPoints.length < 2) return '';
    const first = chartPoints[0];
    const last = chartPoints[chartPoints.length - 1];
    const bottomY = chartHeight - chartPaddingBottom;
    return `${linePath} L ${last.x} ${bottomY} L ${first.x} ${bottomY} Z`;
  }, [linePath, chartPoints]);

  if (reactions.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-xl border border-slate-200 p-8 shadow-2xs">
        <Activity className="w-10 h-10 text-slate-400 mx-auto mb-3" />
        <h3 className="text-base font-bold text-slate-800">No hay reacciones registradas aún</h3>
        <p className="text-xs text-slate-500 mt-1 mb-4">
          Pulsa el botón para registrar tu primer brote alérgico.
        </p>
        <button
          onClick={onAddNew}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors shadow-2xs"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Registrar Brote</span>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4 max-w-full overflow-hidden">
      {/* 1. FILTER TOOLBAR (Identical to SpreadsheetView) */}
      <div className="flex flex-col gap-2.5 p-3 bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-xl shadow-2xs">
        <div className="flex items-center gap-2 w-full">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 dark:text-[#7f91a4] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por zona, notas, medicamento..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-[#17212b] border border-slate-200 dark:border-[#1e2c3a] text-slate-800 dark:text-[#f5f5f5] placeholder:text-slate-400 dark:placeholder:text-[#7f91a4] rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-400 dark:focus:ring-[#5288c1] font-medium"
            />
          </div>

          <button
            type="button"
            onClick={() => setIsFilterPanelOpen(!isFilterPanelOpen)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all shrink-0 select-none shadow-2xs ${
              isFilterPanelOpen || hasActiveFilters
                ? 'bg-slate-900 dark:bg-[#5288c1] text-white border-slate-900 dark:border-[#5288c1] shadow-xs'
                : 'bg-white dark:bg-[#242f3d] text-slate-700 dark:text-[#f5f5f5] border-slate-300 dark:border-[#1e2c3a] hover:bg-slate-50 dark:hover:bg-[#2b394a]'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Filtrar</span>
            {hasActiveFilters && (
              <span className="w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] font-bold flex items-center justify-center ml-0.5">
                !
              </span>
            )}
          </button>
        </div>

        {/* Collapsible Filter Panel */}
        {isFilterPanelOpen && (
          <div className="p-3 bg-slate-50/90 dark:bg-[#17212b]/95 border border-slate-200 dark:border-[#1e2c3a] rounded-xl space-y-2.5 animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-700 dark:text-[#7f91a4] uppercase tracking-wider">
                Filtros por Fecha y Semana
              </span>
              {hasActiveFilters && (
                <button
                  type="button"
                  onClick={clearAllFilters}
                  className="text-[11px] font-semibold text-rose-600 dark:text-rose-400 hover:text-rose-800 dark:hover:text-rose-300 flex items-center gap-1"
                >
                  <X className="w-3 h-3" />
                  <span>Limpiar todos los filtros</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[10px] font-semibold text-slate-500 dark:text-[#7f91a4] uppercase mb-1">
                  Período Temporal:
                </label>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400 dark:text-[#7f91a4] shrink-0" />
                  <select
                    value={selectedTimePeriod}
                    onChange={(e) => {
                      setSelectedTimePeriod(e.target.value);
                      if (e.target.value !== 'custom') {
                        setCustomStartDate('');
                        setCustomEndDate('');
                      }
                    }}
                    className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-lg text-slate-800 dark:text-[#f5f5f5] font-medium focus:outline-none cursor-pointer"
                  >
                    <option value="all">Todo el tiempo</option>
                    <option value="today">Hoy</option>
                    <option value="last_7_days">Últimos 7 días</option>
                    <option value="this_month">Este mes</option>
                    <option value="last_month">Mes anterior</option>
                    <option value="this_year">Este año</option>
                    <option value="custom">📅 Elegir rango de fechas (Desde / Hasta)...</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-semibold text-slate-500 dark:text-[#7f91a4] uppercase mb-1">
                  Filtrar por Semana:
                </label>
                <select
                  value={selectedWeek}
                  onChange={(e) => setSelectedWeek(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-lg text-slate-800 dark:text-[#f5f5f5] font-medium focus:outline-none cursor-pointer"
                >
                  <option value="all">Todas las semanas ({reactions.length})</option>
                  {availableWeeks.map((w) => (
                    <option key={w} value={String(w)}>
                      Semana {w}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {selectedTimePeriod === 'custom' && (
              <div className="pt-2 border-t border-slate-200/80 dark:border-[#1e2c3a] flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-medium text-slate-600 dark:text-[#7f91a4]">Desde:</span>
                  <input
                    type="date"
                    value={customStartDate}
                    onChange={(e) => setCustomStartDate(e.target.value)}
                    className="px-2 py-1 text-xs bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-md text-slate-800 dark:text-[#f5f5f5] focus:outline-none"
                  />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-medium text-slate-600 dark:text-[#7f91a4]">Hasta:</span>
                  <input
                    type="date"
                    value={customEndDate}
                    onChange={(e) => setCustomEndDate(e.target.value)}
                    className="px-2 py-1 text-xs bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-md text-slate-800 dark:text-[#f5f5f5] focus:outline-none"
                  />
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 2. CHRONOLOGICAL LINE CHART (CURVA DE EVOLUCIÓN UAS) */}
      <div className="bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-xl p-3.5 sm:p-4 shadow-2xs overflow-hidden">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-[#1e2c3a]">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400">
              <TrendingUp className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-[#f5f5f5]">
                Evolución Temporal de Gravedad (Escala UAS 0-6)
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-[#7f91a4]">
                {chronologicalData.length > 0
                  ? `${chronologicalData.length} brotes ordenados cronológicamente`
                  : 'Sin datos para la gráfica'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsChartVisible(!isChartVisible)}
              className="text-xs text-slate-500 dark:text-[#7f91a4] hover:text-slate-800 dark:hover:text-[#f5f5f5] p-1 flex items-center gap-1"
              title={isChartVisible ? 'Ocultar gráfica' : 'Mostrar gráfica'}
            >
              <span className="hidden sm:inline text-[11px]">{isChartVisible ? 'Minimizar' : 'Ver gráfica'}</span>
              {isChartVisible ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {isChartVisible && (
          <div className="space-y-2 animate-in fade-in">
            {chronologicalData.length < 2 ? (
              <div className="py-8 text-center text-slate-400 dark:text-[#7f91a4] text-xs">
                Se necesitan al menos 2 registros en el rango seleccionado para trazar la curva de evolución.
              </div>
            ) : (
              <div className="relative w-full">
                <svg
                  viewBox={`0 0 600 ${chartHeight}`}
                  className="w-full h-36 sm:h-44 overflow-visible"
                >
                  <defs>
                    <linearGradient id="uasGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#e11d48" stopOpacity="0.25" />
                      <stop offset="100%" stopColor="#e11d48" stopOpacity="0.0" />
                    </linearGradient>
                  </defs>

                  {/* Horizontal Grid lines (Levels 0, 2, 4, 6) */}
                  {[0, 2, 4, 6].map((score) => {
                    const usableHeight = chartHeight - chartPaddingTop - chartPaddingBottom;
                    const y = chartHeight - chartPaddingBottom - (score / 6) * usableHeight;
                    return (
                      <g key={score}>
                        <line
                          x1={chartPaddingLeft}
                          y1={y}
                          x2={600 - chartPaddingRight}
                          y2={y}
                          stroke="#e2e8f0"
                          className="dark:stroke-[#1e2c3a]"
                          strokeDasharray="3 3"
                        />
                        <text
                          x={chartPaddingLeft - 6}
                          y={y + 3}
                          textAnchor="end"
                          fontSize="9"
                          fill="#94a3b8"
                          className="dark:fill-[#7f91a4]"
                          fontWeight="bold"
                          fontFamily="monospace"
                        >
                          {score}
                        </text>
                      </g>
                    );
                  })}

                  {/* Gradient Area under line */}
                  <path d={areaPath} fill="url(#uasGradient)" />

                  {/* Main Trend Line */}
                  <path
                    d={linePath}
                    fill="none"
                    stroke="#e11d48"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />

                  {/* Data Points */}
                  {chartPoints.map((pt, i) => {
                    const r = pt.data;
                    const isHigh = r.puntuacionDia >= 4;
                    const hasMed = r.tomoMedicamento;

                    return (
                      <g
                        key={r.id}
                        className="cursor-pointer group"
                        onClick={() => setSelectedReactionForDetail(r)}
                      >
                        {/* Stable invisible hit area to prevent mouse flicker / jitter */}
                        <circle
                          cx={pt.x}
                          cy={pt.y}
                          r="14"
                          fill="transparent"
                          className="cursor-pointer"
                        />
                        {/* Visible point with gentle, perfectly centered scale (1.15x) without jitter */}
                        <circle
                          cx={pt.x}
                          cy={pt.y}
                          r={isHigh ? 5 : 4}
                          fill={isHigh ? '#e11d48' : hasMed ? '#059669' : '#5288c1'}
                          stroke="#ffffff"
                          strokeWidth="2"
                          className="pointer-events-none transition-transform duration-150 ease-out group-hover:scale-125"
                          style={{
                            transformOrigin: `${pt.x}px ${pt.y}px`,
                          }}
                        />
                        {/* Hover Tooltip Title */}
                        <title>
                          {`${r.fechaFormateada} — Puntuación: ${r.puntuacionDia}/6${
                            hasMed ? ` (Medicado: ${r.medicamento || 'Sí'})` : ''
                          }`}
                        </title>

                        {/* Date label at bottom for selected spacing */}
                        {(i === 0 || i === chartPoints.length - 1 || i % Math.ceil(chartPoints.length / 5) === 0) && (
                          <text
                            x={pt.x}
                            y={chartHeight - 8}
                            textAnchor="middle"
                            fontSize="8"
                            fill="#64748b"
                            className="dark:fill-[#7f91a4]"
                            fontWeight="500"
                          >
                            {r.fechaFormateada.slice(0, 5)}
                          </text>
                        )}
                      </g>
                    );
                  })}
                </svg>

                {/* Legend bar */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-[10px] text-slate-500 dark:text-[#7f91a4] border-t border-slate-100 dark:border-[#1e2c3a]">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-slate-700 dark:bg-slate-400"></span>
                      Sin medicación
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-600 dark:bg-emerald-400"></span>
                      Con antihistamínico / medicación
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-rose-600 dark:bg-rose-400"></span>
                      Brote severo (4-6)
                    </span>
                  </div>
                  <span className="italic text-slate-400 dark:text-[#7f91a4]">
                    Pulsa en cualquier punto para ampliar el brote
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 3. TIMELINE CARDS GRID */}
      {filtered.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-[#242f3d] rounded-xl border border-slate-200 dark:border-[#1e2c3a] p-8 shadow-2xs">
          <p className="font-semibold text-slate-700 dark:text-[#f5f5f5] text-sm">
            No se encontraron brotes con los filtros seleccionados
          </p>
          <p className="text-xs text-slate-500 dark:text-[#7f91a4] mt-1">
            Prueba a ampliar el rango de fechas o limpiar los filtros.
          </p>
          <button
            onClick={clearAllFilters}
            className="mt-3 px-3 py-1.5 bg-slate-100 dark:bg-[#17212b] hover:bg-slate-200 dark:hover:bg-[#2b394a] text-slate-700 dark:text-[#f5f5f5] rounded-lg text-xs font-semibold transition-colors"
          >
            Restablecer filtros
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
          {filtered.map((r) => {
            const uas = getUASLevel(r.puntuacionDia);

            return (
              <div
                key={r.id}
                className="bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-xl p-4 flex flex-col justify-between hover:shadow-sm hover:border-slate-300 dark:hover:border-[#2b394a] transition-all cursor-pointer group"
                onClick={(e) => {
                  const target = e.target as HTMLElement;
                  if (target.closest('button')) return;
                  setSelectedReactionForDetail(r);
                }}
              >
                <div>
                  {/* Header: Date, Week, and UAS Score */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div>
                      <div className="font-mono text-xs font-bold text-slate-900 dark:text-[#f5f5f5] group-hover:text-rose-600 dark:group-hover:text-[#64b5f6] transition-colors">
                        {r.fechaFormateada}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-[#7f91a4] flex items-center gap-1.5 mt-0.5">
                        <span>Semana {r.semana}</span>
                        {r.ubicacion && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="flex items-center gap-0.5">
                              <MapPin className="w-3 h-3 text-slate-400 dark:text-[#7f91a4]" />
                              {r.ubicacion}
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    <div
                      className={`px-2.5 py-1 rounded-md text-xs font-bold border ${uas.badgeClass} shrink-0`}
                      title={`Ronchas: ${r.ronchas ?? r.numHabones ?? 0}/3 | Prurito: ${r.prurito}/3`}
                    >
                      UAS: {r.puntuacionDia}/6 · {uas.label}
                    </div>
                  </div>

                  {/* Body Location */}
                  <div className="mb-3 bg-slate-50 dark:bg-[#17212b] p-2.5 rounded-lg border border-slate-100 dark:border-[#1e2c3a]">
                    <span className="text-[11px] font-semibold text-slate-500 dark:text-[#7f91a4] block mb-0.5">
                      Zona corporal afectada:
                    </span>
                    <p className="text-xs font-medium text-slate-800 dark:text-[#f5f5f5]">
                      {r.ubicacionCuerpo || 'No especificada'}
                    </p>
                  </div>

                  {/* Clinical Metrics (Ronchas & Prurito) */}
                  <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                    <div className="bg-slate-50/70 dark:bg-[#17212b] p-2 rounded-lg border border-slate-100 dark:border-[#1e2c3a]">
                      <span className="text-[10px] text-slate-500 dark:text-[#7f91a4] block font-medium">Nº Ronchas (0-3)</span>
                      <div className="font-mono font-bold text-slate-900 dark:text-[#f5f5f5] text-sm mt-0.5">
                        {r.ronchas ?? r.numHabones ?? 0}{' '}
                        <span className="text-[10px] font-normal text-slate-500 dark:text-[#7f91a4]">
                          {(r.ronchas ?? r.numHabones ?? 0) === 0
                            ? '(0)'
                            : (r.ronchas ?? r.numHabones ?? 0) === 1
                            ? '(<20)'
                            : (r.ronchas ?? r.numHabones ?? 0) === 2
                            ? '(20-50)'
                            : '(>50)'}
                        </span>
                      </div>
                    </div>

                    <div className="bg-slate-50/70 dark:bg-[#17212b] p-2 rounded-lg border border-slate-100 dark:border-[#1e2c3a]">
                      <span className="text-[10px] text-slate-500 dark:text-[#7f91a4] block font-medium">Prurito (0-3)</span>
                      <div className="font-mono font-bold text-slate-900 dark:text-[#f5f5f5] text-sm mt-0.5">
                        {r.prurito}{' '}
                        <span className="text-[10px] font-normal text-slate-500 dark:text-[#7f91a4]">
                          {r.prurito === 0
                            ? '(Ninguno)'
                            : r.prurito === 1
                            ? '(Leve)'
                            : r.prurito === 2
                            ? '(Moderado)'
                            : '(Intenso)'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Medication & Duration */}
                  <div className="space-y-1.5 text-xs pt-1 border-t border-slate-100 dark:border-[#1e2c3a]">
                    <div className="flex items-center justify-between text-slate-700 dark:text-[#f5f5f5]">
                      <span className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-[#7f91a4]">
                        <Pill className="w-3.5 h-3.5 text-slate-400 dark:text-[#7f91a4]" />
                        Medicación:
                      </span>
                      <span className="font-medium text-right truncate max-w-[170px]">
                        {r.tomoMedicamento
                          ? r.medicamento || 'Sí (medicado)'
                          : 'No tomó medicamento'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-slate-700 dark:text-[#f5f5f5]">
                      <span className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-[#7f91a4]">
                        <Clock className="w-3.5 h-3.5 text-slate-400 dark:text-[#7f91a4]" />
                        Tiempo en desaparecer:
                      </span>
                      <span className="font-mono tabular-nums font-semibold text-slate-900 dark:text-[#f5f5f5]">
                        {r.tiempoDesaparecer || 'En curso / No medido'}
                      </span>
                    </div>

                    {/* Photos Preview on Card */}
                    {r.fotos && r.fotos.length > 0 && (
                      <div className="pt-2 flex items-center gap-1.5 overflow-hidden">
                        {r.fotos.slice(0, 3).map((foto, fIdx) => (
                          <button
                            key={fIdx}
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setPreviewPhotoUrl(foto);
                            }}
                            className="w-12 h-12 rounded-lg overflow-hidden border border-slate-200 dark:border-[#1e2c3a] shrink-0 bg-slate-100 dark:bg-[#17212b] hover:opacity-90 active:scale-95 transition-all cursor-pointer shadow-2xs"
                            title="Tocar para ampliar fotografía con zoom"
                          >
                            <img
                              src={foto}
                              alt="Miniatura brote"
                              className="w-full h-full object-cover"
                            />
                          </button>
                        ))}
                        {r.fotos.length > 3 && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedReactionForDetail(r);
                            }}
                            className="text-[10px] text-slate-500 dark:text-[#7f91a4] hover:text-slate-900 dark:hover:text-[#f5f5f5] font-semibold bg-slate-100 dark:bg-[#17212b] hover:bg-slate-200 dark:hover:bg-[#2b394a] px-1.5 py-1 rounded-md transition-colors"
                          >
                            +{r.fotos.length - 3}
                          </button>
                        )}
                      </div>
                    )}

                    {r.notas && (
                      <p className="text-[11px] text-slate-600 dark:text-amber-200 bg-amber-50/60 dark:bg-amber-950/30 p-2 rounded border border-amber-100 dark:border-amber-900/50 mt-2 truncate">
                        <strong className="font-semibold text-amber-900 dark:text-amber-300">Nota: </strong>
                        {r.notas}
                      </p>
                    )}
                  </div>
                </div>

                {/* Card Actions */}
                <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-100 dark:border-[#1e2c3a] text-xs">
                  <button
                    onClick={() => setSelectedReactionForDetail(r)}
                    className="inline-flex items-center gap-1 text-slate-500 dark:text-[#7f91a4] hover:text-slate-800 dark:hover:text-[#f5f5f5] font-medium p-1"
                    title="Ampliar detalle"
                  >
                    <Eye className="w-3.5 h-3.5 text-slate-400 dark:text-[#7f91a4]" />
                    <span>Ampliar</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onDuplicate(r)}
                      className="p-1.5 text-slate-500 dark:text-[#7f91a4] hover:text-slate-900 dark:hover:text-[#f5f5f5] hover:bg-slate-100 dark:hover:bg-[#2b394a] rounded transition-colors"
                      title="Duplicar"
                    >
                      <CopyPlus className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onEdit(r)}
                      className="p-1.5 text-slate-500 dark:text-[#7f91a4] hover:text-slate-900 dark:hover:text-[#f5f5f5] hover:bg-slate-100 dark:hover:bg-[#2b394a] rounded transition-colors"
                      title="Editar"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onDelete(r.id)}
                      className="p-1.5 text-slate-400 dark:text-[#7f91a4] hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded transition-colors"
                      title="Eliminar"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* DETAIL MODAL (AMPLIAR) */}
      <ReactionDetailModal
        reaction={selectedReactionForDetail}
        onClose={() => setSelectedReactionForDetail(null)}
        onEdit={(reaction) => {
          setSelectedReactionForDetail(null);
          onEdit(reaction);
        }}
        onDelete={(id) => {
          setSelectedReactionForDetail(null);
          onDelete(id);
        }}
      />

      {/* FULLSCREEN PHOTO LIGHTBOX WITH PINCH ZOOM & DESKTOP CONTROLS */}
      <PhotoLightboxModal
        imageUrl={previewPhotoUrl}
        onClose={() => setPreviewPhotoUrl(null)}
        title="Fotografía del brote alérgico"
      />
    </div>
  );
};
