import React, { useState } from 'react';
import {
  X,
  Calendar,
  Clock,
  MapPin,
  Pill,
  FileText,
  AlertCircle,
  Copy,
  Printer,
  Edit2,
  Trash2,
  Share2,
  Camera,
  ZoomIn,
  Maximize2,
} from 'lucide-react';
import { AllergyReaction } from '../types/allergy';
import { MiniBodyPreview } from './MiniBodyPreview';
import { PhotoLightboxModal } from './PhotoLightboxModal';

interface ReactionDetailModalProps {
  reaction: AllergyReaction | null;
  onClose: () => void;
  onEdit: (reaction: AllergyReaction) => void;
  onDelete: (id: string) => void;
}

export const ReactionDetailModal: React.FC<ReactionDetailModalProps> = ({
  reaction,
  onClose,
  onEdit,
  onDelete,
}) => {
  const [selectedPreviewImage, setSelectedPreviewImage] = useState<string | null>(null);

  if (!reaction) return null;

  const getSeverityBadge = (score: number) => {
    if (score === 0) {
      return {
        bg: 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 border-emerald-200 dark:border-emerald-800/60',
        pill: 'bg-white dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 border-emerald-300 dark:border-emerald-700',
        label: 'Sin síntomas (0/6)',
      };
    }
    if (score <= 2) {
      return {
        bg: 'bg-amber-50 dark:bg-[#1a2332] text-amber-900 dark:text-[#f5f5f5] border-amber-200 dark:border-[#2b394a]',
        pill: 'bg-white dark:bg-[#242f3d] text-amber-800 dark:text-amber-300 border-amber-300 dark:border-amber-700/60',
        label: `Leve (${score}/6)`,
      };
    }
    if (score <= 4) {
      return {
        bg: 'bg-orange-50 dark:bg-[#1f2633] text-orange-950 dark:text-[#f5f5f5] border-orange-200 dark:border-orange-800/60',
        pill: 'bg-white dark:bg-[#242f3d] text-orange-800 dark:text-orange-300 border-orange-300 dark:border-orange-700/60',
        label: `Moderado (${score}/6)`,
      };
    }
    return {
      bg: 'bg-rose-50 dark:bg-[#241c24] text-rose-950 dark:text-[#f5f5f5] border-rose-200 dark:border-rose-900/60',
      pill: 'bg-white dark:bg-[#242f3d] text-rose-700 dark:text-rose-300 border-rose-300 dark:border-rose-700/60',
      label: `Severo (${score}/6)`,
    };
  };

  const badge = getSeverityBadge(reaction.puntuacionDia);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 dark:bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white dark:bg-[#242f3d] w-full max-w-lg rounded-2xl shadow-xl border border-slate-200 dark:border-[#1e2c3a] overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 dark:border-[#1e2c3a] bg-slate-50/80 dark:bg-[#17212b]">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-100 dark:border-rose-900 flex items-center justify-center text-rose-600 dark:text-rose-400 font-bold text-xs">
              S{reaction.semana}
            </span>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-[#f5f5f5] text-sm">
                Detalle del Registro Clínico
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-[#7f91a4]">
                {reaction.fechaFormateada}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 dark:text-[#7f91a4] hover:text-slate-700 dark:hover:text-[#f5f5f5] hover:bg-slate-100 dark:hover:bg-[#2b394a] transition-colors"
            title="Cerrar ventana"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* Severity Banner */}
          <div className={`p-3 rounded-xl border flex items-center justify-between shadow-2xs transition-colors ${badge.bg}`}>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider block opacity-90">
                Puntuación UAS Diaria
              </span>
              <span className="text-base font-extrabold font-mono">
                {reaction.puntuacionDia} / 6 puntos
              </span>
            </div>
            <span className={`font-bold px-2.5 py-1 rounded-full border text-[11px] shadow-2xs ${badge.pill}`}>
              {badge.label}
            </span>
          </div>

          {/* Clinical Scores Breakdown Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-slate-50 dark:bg-[#17212b] border border-slate-100 dark:border-[#1e2c3a] rounded-xl space-y-1">
              <span className="text-[10px] font-bold text-slate-400 dark:text-[#7f91a4] uppercase tracking-wide">
                Nº de Ronchas (Habones)
              </span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-lg font-bold font-mono text-slate-900 dark:text-[#f5f5f5]">
                  {reaction.ronchas ?? (reaction as any).numHabones ?? 0}
                </span>
                <span className="text-[11px] text-slate-500 dark:text-[#7f91a4]">
                  {(reaction.ronchas ?? (reaction as any).numHabones ?? 0) === 0
                    ? 'Sin ronchas'
                    : (reaction.ronchas ?? (reaction as any).numHabones ?? 0) === 1
                    ? 'Leve (<20)'
                    : (reaction.ronchas ?? (reaction as any).numHabones ?? 0) === 2
                    ? 'Moderado (20-50)'
                    : 'Severo (>50)'}
                </span>
              </div>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-[#17212b] border border-slate-100 dark:border-[#1e2c3a] rounded-xl space-y-1">
              <span className="text-[10px] font-bold text-slate-400 dark:text-[#7f91a4] uppercase tracking-wide">
                Intensidad Prurito (Picor)
              </span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-lg font-bold font-mono text-slate-900 dark:text-[#f5f5f5]">
                  {reaction.prurito}
                </span>
                <span className="text-[11px] text-slate-500 dark:text-[#7f91a4]">
                  {reaction.prurito === 0
                    ? 'Sin picor'
                    : reaction.prurito === 1
                    ? 'Leve'
                    : reaction.prurito === 2
                    ? 'Moderado'
                    : 'Intenso'}
                </span>
              </div>
            </div>
          </div>

          {/* Anatomical Locations & Environment */}
          <div className="space-y-2.5 bg-slate-50/70 dark:bg-[#17212b] border border-slate-100 dark:border-[#1e2c3a] p-3.5 rounded-xl">
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
              <div className="flex-1">
                <span className="font-bold text-slate-700 dark:text-[#7f91a4] block">Zonas afectadas del cuerpo:</span>
                <p className="text-slate-900 dark:text-[#f5f5f5] font-semibold mt-0.5">
                  {reaction.ubicacionCuerpo || 'No especificadas'}
                </p>
              </div>
            </div>

            {/* Anatomical Mini Body Figure showing affected rash zones */}
            <MiniBodyPreview
              selectedRegions={reaction.cuerpoZonasSeleccionadas}
              ubicacionCuerpo={reaction.ubicacionCuerpo}
            />

            <div className="flex items-start gap-2 pt-2 border-t border-slate-200/60 dark:border-[#1e2c3a]">
              <Clock className="w-4 h-4 text-indigo-500 dark:text-[#64b5f6] shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-700 dark:text-[#7f91a4] block">Lugar / Entorno del brote:</span>
                <p className="text-slate-900 dark:text-[#f5f5f5] font-semibold mt-0.5">
                  {reaction.ubicacion || 'No indicado'}
                </p>
              </div>
            </div>
          </div>

          {/* Medication details */}
          <div className="p-3.5 rounded-xl border border-slate-100 dark:border-[#1e2c3a] bg-slate-50/70 dark:bg-[#17212b] space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Pill className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span className="font-bold text-slate-800 dark:text-[#f5f5f5]">Tratamiento Farmacológico:</span>
              </div>
              <span
                className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                  reaction.tomoMedicamento
                    ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                    : 'bg-slate-200 dark:bg-[#242f3d] text-slate-700 dark:text-[#7f91a4]'
                }`}
              >
                {reaction.tomoMedicamento ? 'Sí tomó medicación' : 'No tomó'}
              </span>
            </div>

            {reaction.tomoMedicamento && (
              <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
                <div className="bg-white dark:bg-[#242f3d] p-2 rounded-lg border border-slate-200 dark:border-[#2b394a]">
                  <span className="text-slate-400 dark:text-[#7f91a4] block text-[10px]">Fármaco / Antihistamínico:</span>
                  <span className="font-bold text-slate-800 dark:text-[#f5f5f5]">{reaction.medicamento || '-'}</span>
                </div>
                <div className="bg-white dark:bg-[#242f3d] p-2 rounded-lg border border-slate-200 dark:border-[#2b394a]">
                  <span className="text-slate-400 dark:text-[#7f91a4] block text-[10px]">Dosis tomada:</span>
                  <span className="font-bold text-slate-800 dark:text-[#f5f5f5]">{reaction.dosis || '-'}</span>
                </div>
              </div>
            )}
          </div>

          {/* Rash Photos Gallery (Para el médico / alergólogo) */}
          {reaction.fotos && reaction.fotos.length > 0 && (
            <div className="p-3.5 bg-slate-50 dark:bg-[#17212b] border border-slate-200/80 dark:border-[#1e2c3a] rounded-xl space-y-2">
              <div className="flex items-center gap-1.5 text-slate-800 dark:text-[#f5f5f5] font-bold">
                <Camera className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                <span>Fotografías del Brote Alérgico ({reaction.fotos.length}):</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
                {reaction.fotos.map((foto, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSelectedPreviewImage(foto)}
                    className="group relative rounded-xl overflow-hidden border border-slate-200 dark:border-[#2b394a] aspect-square bg-slate-100 dark:bg-[#242f3d] shadow-2xs hover:shadow-md transition-all text-left focus:outline-none focus:ring-2 focus:ring-rose-500"
                    title="Pulsar para ampliar y ver la foto en grande"
                  >
                    <img
                      src={foto}
                      alt={`Foto brote ${idx + 1}`}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                    />
                    <div className="absolute inset-0 bg-slate-900/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <span className="p-1.5 rounded-full bg-white/90 dark:bg-[#242f3d]/90 text-slate-800 dark:text-[#f5f5f5] shadow-sm">
                        <ZoomIn className="w-4 h-4" />
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Clinical Notes & Observations */}
          {reaction.notas && (
            <div className="p-3.5 bg-slate-50 dark:bg-[#17212b] border border-slate-100 dark:border-[#1e2c3a] rounded-xl space-y-1">
              <div className="flex items-center gap-1.5 text-slate-700 dark:text-[#7f91a4] font-bold">
                <FileText className="w-3.5 h-3.5 text-slate-400 dark:text-[#7f91a4]" />
                <span>Observaciones clínicas y factores detonantes:</span>
              </div>
              <p className="text-slate-600 dark:text-[#f5f5f5] leading-relaxed italic bg-white dark:bg-[#242f3d] p-2.5 rounded-lg border border-slate-200 dark:border-[#2b394a] mt-1">
                "{reaction.notas}"
              </p>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-slate-100 dark:border-[#1e2c3a] bg-slate-50/50 dark:bg-[#17212b]">
          <button
            onClick={() => onDelete(reaction.id)}
            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:text-rose-800 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Eliminar</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onEdit(reaction);
              }}
              className="inline-flex items-center gap-1 px-3.5 py-1.5 text-xs font-bold text-white bg-slate-900 dark:bg-[#5288c1] hover:bg-slate-800 dark:hover:bg-[#64b5f6] rounded-lg transition-colors shadow-2xs"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>Editar</span>
            </button>
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 dark:text-[#f5f5f5] hover:text-slate-900 bg-white dark:bg-[#242f3d] border border-slate-200 dark:border-[#1e2c3a] rounded-lg hover:bg-slate-100 dark:hover:bg-[#2b394a] transition-colors"
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>

      {/* FULLSCREEN LIGHTBOX PHOTO VIEWER WITH PINCH-TO-ZOOM & DESKTOP CONTROLS */}
      <PhotoLightboxModal
        imageUrl={selectedPreviewImage}
        onClose={() => setSelectedPreviewImage(null)}
        title="Fotografía del brote alérgico"
      />
    </div>
  );
};
