import React, { useEffect, useState } from 'react';
import { WifiOff, CheckCircle2 } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  const [showRestoredNotice, setShowRestoredNotice] = useState<boolean>(false);
  const [hasBeenOffline, setHasBeenOffline] = useState<boolean>(false);

  useEffect(() => {
    if (!isOnline) {
      setHasBeenOffline(true);
    } else if (hasBeenOffline) {
      setShowRestoredNotice(true);
      const timer = setTimeout(() => {
        setShowRestoredNotice(false);
        setHasBeenOffline(false);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [isOnline, hasBeenOffline]);

  if (isOnline && !showRestoredNotice) return null;

  if (showRestoredNotice) {
    return (
      <div className="fixed bottom-4 right-4 z-50 flex items-center gap-2.5 rounded-xl bg-emerald-700 text-white px-3.5 py-2 text-xs font-semibold shadow-xl border border-emerald-500 animate-in fade-in slide-in-from-bottom-2">
        <CheckCircle2 className="w-4 h-4 text-emerald-200 shrink-0" />
        <span>Conexión restablecida · Datos sincronizados en la nube</span>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 flex items-center gap-2.5 rounded-xl bg-slate-900/95 backdrop-blur-md text-amber-300 px-3.5 py-2 text-xs font-semibold shadow-2xl border border-amber-500/30 animate-in fade-in slide-in-from-bottom-2">
      <span className="relative flex h-2.5 w-2.5 shrink-0">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
      </span>
      <WifiOff className="w-4 h-4 text-amber-400 shrink-0" />
      <div className="flex flex-col">
        <span className="text-white font-bold">Modo Sin Conexión (Offline)</span>
        <span className="text-[11px] text-slate-300 font-normal">
          Puedes registrar brotes normalmente. Se guardarán en tu dispositivo.
        </span>
      </div>
    </div>
  );
};
