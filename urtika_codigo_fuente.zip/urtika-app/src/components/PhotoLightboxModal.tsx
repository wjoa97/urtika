import React, { useState, useEffect, useRef, useCallback } from 'react';
import { X, ZoomIn, ZoomOut, RotateCcw, Camera } from 'lucide-react';

interface PhotoLightboxModalProps {
  imageUrl: string | null;
  onClose: () => void;
  title?: string;
}

export const PhotoLightboxModal: React.FC<PhotoLightboxModalProps> = ({
  imageUrl,
  onClose,
  title = 'Fotografía del brote',
}) => {
  const [scale, setScale] = useState<number>(1);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);

  // Mutable refs to prevent stale closures inside non-passive DOM listeners
  const scaleRef = useRef<number>(1);
  const positionRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const isDraggingRef = useRef<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const initialPositionRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const initialPinchDistanceRef = useRef<number | null>(null);
  const initialPinchScaleRef = useRef<number>(1);
  const lastTapRef = useRef<number>(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const updateScale = useCallback((newScale: number) => {
    const clamped = Math.min(Math.max(newScale, 1), 6);
    scaleRef.current = clamped;
    setScale(clamped);
    if (clamped === 1) {
      positionRef.current = { x: 0, y: 0 };
      setPosition({ x: 0, y: 0 });
    }
  }, []);

  const updatePosition = useCallback((newPos: { x: number; y: number }) => {
    positionRef.current = newPos;
    setPosition(newPos);
  }, []);

  const handleZoomIn = () => {
    updateScale(scaleRef.current + 0.5);
  };

  const handleZoomOut = () => {
    updateScale(scaleRef.current - 0.5);
  };

  const handleResetZoom = () => {
    scaleRef.current = 1;
    positionRef.current = { x: 0, y: 0 };
    setScale(1);
    setPosition({ x: 0, y: 0 });
  };

  // Reset scale and position whenever a new image opens
  useEffect(() => {
    handleResetZoom();
  }, [imageUrl]);

  // Lock body scroll while lightbox is open and listen for ESC key
  useEffect(() => {
    if (!imageUrl) return;

    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === '+' || e.key === '=') {
        handleZoomIn();
      } else if (e.key === '-') {
        handleZoomOut();
      } else if (e.key === '0') {
        handleResetZoom();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = originalOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [imageUrl]);

  // Non-passive Touch Event Listeners for smooth Mobile Pinch-to-Zoom
  useEffect(() => {
    const el = containerRef.current;
    if (!el || !imageUrl) return;

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        // 2 fingers pinch: prevent native page zooming
        e.preventDefault();
        const touch1 = e.touches[0];
        const touch2 = e.touches[1];
        const dist = Math.hypot(
          touch1.clientX - touch2.clientX,
          touch1.clientY - touch2.clientY
        );
        initialPinchDistanceRef.current = dist;
        initialPinchScaleRef.current = scaleRef.current;
      } else if (e.touches.length === 1) {
        // 1 finger: detect double tap or start pan
        const now = Date.now();
        if (now - lastTapRef.current < 300) {
          e.preventDefault();
          if (scaleRef.current > 1) {
            handleResetZoom();
          } else {
            updateScale(2.5);
          }
          lastTapRef.current = 0;
          return;
        }
        lastTapRef.current = now;

        if (scaleRef.current > 1) {
          isDraggingRef.current = true;
          setIsDragging(true);
          dragStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
          initialPositionRef.current = { ...positionRef.current };
        }
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2 && initialPinchDistanceRef.current !== null) {
        // Pinching to zoom: prevent browser viewport zoom
        e.preventDefault();
        const touch1 = e.touches[0];
        const touch2 = e.touches[1];
        const currentDistance = Math.hypot(
          touch1.clientX - touch2.clientX,
          touch1.clientY - touch2.clientY
        );
        const ratio = currentDistance / initialPinchDistanceRef.current;
        const newScale = Math.min(Math.max(initialPinchScaleRef.current * ratio, 1), 6);
        updateScale(newScale);
      } else if (e.touches.length === 1 && isDraggingRef.current && scaleRef.current > 1) {
        // Panning image while zoomed
        e.preventDefault();
        const dx = e.touches[0].clientX - dragStartRef.current.x;
        const dy = e.touches[0].clientY - dragStartRef.current.y;
        updatePosition({
          x: initialPositionRef.current.x + dx,
          y: initialPositionRef.current.y + dy,
        });
      }
    };

    const onTouchEnd = (e: TouchEvent) => {
      if (e.touches.length < 2) {
        initialPinchDistanceRef.current = null;
      }
      if (e.touches.length === 0) {
        isDraggingRef.current = false;
        setIsDragging(false);
        if (scaleRef.current < 1.05) {
          handleResetZoom();
        }
      }
    };

    // Attach non-passive listeners so e.preventDefault() works on iOS and Android
    el.addEventListener('touchstart', onTouchStart, { passive: false });
    el.addEventListener('touchmove', onTouchMove, { passive: false });
    el.addEventListener('touchend', onTouchEnd, { passive: false });
    el.addEventListener('touchcancel', onTouchEnd, { passive: false });

    return () => {
      el.removeEventListener('touchstart', onTouchStart);
      el.removeEventListener('touchmove', onTouchMove);
      el.removeEventListener('touchend', onTouchEnd);
      el.removeEventListener('touchcancel', onTouchEnd);
    };
  }, [imageUrl, updateScale, updatePosition]);

  if (!imageUrl) return null;

  // Mouse wheel zoom (Desktop)
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 0.3 : -0.3;
    updateScale(scaleRef.current + zoomFactor);
  };

  // Mouse drag handlers (Desktop pan)
  const handleMouseDown = (e: React.MouseEvent) => {
    if (scale <= 1) return;
    setIsDragging(true);
    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX, y: e.clientY };
    initialPositionRef.current = { ...position };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || scale <= 1) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    updatePosition({
      x: initialPositionRef.current.x + dx,
      y: initialPositionRef.current.y + dy,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    isDraggingRef.current = false;
  };

  return (
    <div
      className="fixed inset-0 z-60 bg-slate-950/95 backdrop-blur-md flex flex-col justify-between p-2 sm:p-4 animate-in fade-in duration-200 select-none touch-none"
      onClick={(e) => {
        // Close if clicking the outer backdrop directly
        if (e.target === containerRef.current || e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      {/* Top Header Bar */}
      <div className="w-full max-w-5xl mx-auto flex items-center justify-between py-1.5 px-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/15 text-white z-20 shrink-0">
        <div className="flex items-center gap-2">
          <Camera className="w-4 h-4 text-rose-400 shrink-0" />
          <span className="text-xs sm:text-sm font-semibold truncate max-w-[200px] sm:max-w-none">
            {title}
          </span>
        </div>

        {/* Right side: Close button */}
        <button
          type="button"
          onClick={onClose}
          className="p-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-white/15 hover:bg-white/25 active:bg-white/30 text-white transition-colors flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
          title="Cerrar visor"
        >
          <X className="w-4 h-4" />
          <span className="hidden sm:inline">Cerrar</span>
        </button>
      </div>

      {/* Center Image Canvas Area */}
      <div
        ref={containerRef}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="flex-1 w-full max-w-5xl mx-auto flex items-center justify-center overflow-hidden relative my-2"
        style={{ cursor: scale > 1 ? (isDragging ? 'grabbing' : 'grab') : 'default' }}
      >
        <div
          className="relative transition-transform duration-75 will-change-transform flex items-center justify-center max-w-full max-h-full"
          style={{
            transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
          }}
        >
          <img
            src={imageUrl}
            alt="Fotografía de la erupción ampliada"
            draggable={false}
            className="w-auto h-auto max-w-[92vw] max-h-[75vh] object-contain rounded-xl shadow-2xl select-none pointer-events-none"
          />
        </div>
      </div>

      {/* Bottom Floating Control Bar (Zoom buttons accessible on both Mobile & Web) */}
      <div className="w-full max-w-md mx-auto flex flex-col items-center gap-1.5 z-20 shrink-0 pb-1">
        <div className="flex items-center gap-1.5 sm:gap-2 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-2xl border border-white/20 shadow-2xl text-white">
          {/* Zoom Out Button */}
          <button
            type="button"
            onClick={handleZoomOut}
            disabled={scale <= 1}
            className="p-2 sm:p-2.5 rounded-xl hover:bg-white/15 active:bg-white/25 disabled:opacity-35 transition-colors text-slate-100 cursor-pointer"
            title="Reducir zoom (-)"
            aria-label="Reducir zoom"
          >
            <ZoomOut className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Zoom Percentage Label */}
          <button
            type="button"
            onClick={handleResetZoom}
            className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs sm:text-sm font-mono font-bold tracking-tight text-white transition-colors min-w-[58px] text-center cursor-pointer"
            title="Restablecer tamaño original (100%)"
          >
            {Math.round(scale * 100)}%
          </button>

          {/* Zoom In Button */}
          <button
            type="button"
            onClick={handleZoomIn}
            disabled={scale >= 6}
            className="p-2 sm:p-2.5 rounded-xl hover:bg-white/15 active:bg-white/25 disabled:opacity-35 transition-colors text-slate-100 cursor-pointer"
            title="Aumentar zoom (+)"
            aria-label="Aumentar zoom"
          >
            <ZoomIn className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          <div className="h-4 w-px bg-white/20 mx-0.5" />

          {/* Reset Zoom Button */}
          <button
            type="button"
            onClick={handleResetZoom}
            disabled={scale === 1 && position.x === 0 && position.y === 0}
            className="p-2 sm:p-2.5 rounded-xl hover:bg-white/15 active:bg-white/25 disabled:opacity-35 transition-colors text-slate-100 flex items-center gap-1 text-xs cursor-pointer"
            title="Restablecer al centro y 100%"
          >
            <RotateCcw className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="hidden sm:inline text-[11px] font-semibold">1:1</span>
          </button>
        </div>

        {/* Gesture / Usage hints */}
        <p className="text-[10px] text-slate-400 text-center tracking-tight px-2">
          📱 Pellizca con 2 dedos o pulsa los botones (+) (-) · Doble toque para 2.5x · Arrastra para mover
        </p>
      </div>
    </div>
  );
};
