import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { AuthProvider } from './firebase/AuthContext';
import { ThemeProvider } from './theme/ThemeContext';

import { registerSW } from 'virtual:pwa-register';

// Register Service Worker for true Offline PWA capabilities
if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  try {
    registerSW({
      immediate: true,
      onNeedRefresh() {
        console.log('Nueva versión disponible');
      },
      onOfflineReady() {
        console.log('App lista para uso offline');
      },
    });
  } catch (err) {
    console.warn('PWA Service Worker registration skipped:', err);
  }
}

createRoot(document.getElementById('root')!).render(
  <ThemeProvider>
    <AuthProvider>
      <App />
    </AuthProvider>
  </ThemeProvider>
);
